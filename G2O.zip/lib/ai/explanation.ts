import { RankedOpportunityResult } from '@/types/opportunity';
import { SearchQueryModel } from '@/types/discovery';

export function generateMatchExplanation(
  match: RankedOpportunityResult,
  query: SearchQueryModel
): {
  headline: string;
  summaryText: string;
  howThisHelps: string;
  checklist: { label: string; passed: boolean; details: string }[];
  preferenceNotice?: string;
} {
  const opp = match.opportunity;

  const headline = `${opp.title} is a ${match.totalScore}% match for your goal.`;

  const feeText = opp.fee === 0 ? 'has a stored fee of ₹0' : `has a stored fee of ₹${opp.fee}`;
  const summaryText = `${opp.title} is a ${opp.opportunityType} in the stored ${opp.domain} domain. Its listing says: ${opp.shortDescription} The listing ${feeText}.`;

  const listedSkills = opp.skills.length ? opp.skills.slice(0, 3).join(', ') : 'no skills were supplied by the source';
  const howThisHelps = `The listing is organized by ${opp.organizer} and names these skills/topics: ${listedSkills}. The relevance score is based on the validated query and event fields, not additional generated claims.`;

  const checklist = [
    {
      label: query.skillLevel || 'Beginner Friendly',
      passed: opp.difficulty === (query.skillLevel || 'Beginner') || opp.difficulty === 'All Levels',
      details: `${opp.difficulty} difficulty`,
    },
    {
      label: query.budgetMax !== null && query.budgetMax !== undefined ? `Budget ≤ ₹${query.budgetMax}` : 'Budget Fit',
      passed: query.budgetMax !== null && query.budgetMax !== undefined ? opp.fee <= query.budgetMax : true,
      details: opp.fee === 0 ? 'Free Event' : `₹${opp.fee}`,
    },
    {
      label: query.dateRange || 'Date Availability',
      passed: query.dateRange !== 'THIS_WEEKEND' || [0, 6].includes(new Date(opp.startDate).getDay()),
      details: `Starts ${new Date(opp.startDate).toISOString().slice(0, 10)}`,
    },
    {
      label: 'Student Eligible',
      passed: !query.eligibility?.degree || opp.eligibleDegrees.some((degree) => degree === 'Any' || degree.toLowerCase() === query.eligibility!.degree!.toLowerCase()),
      details: opp.eligibilityText,
    },
    {
      label: `${query.domains[0] || 'AI / ML'} Domain`,
      passed: query.domains.some((domain) => opp.domain.toLowerCase().includes(domain.toLowerCase().replace('ai/ml', 'ai'))),
      details: opp.domain,
    },
  ];

  let preferenceNotice: string | undefined = undefined;
  if (match.mismatches.length > 0) {
    preferenceNotice = match.mismatches.join('. ');
  }

  return {
    headline,
    summaryText,
    howThisHelps,
    checklist,
    preferenceNotice,
  };
}
