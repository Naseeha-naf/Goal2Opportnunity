import { z } from 'zod';
import OpenAI from 'openai';
import { SearchQueryModel } from '@/types/discovery';
import { OpportunityType, EventMode, SkillLevel } from '@/types/opportunity';

const OpportunityTypesEnum = z.enum([
  'Hackathon',
  'Workshop',
  'Competition',
  'Internship',
  'Open Source',
  'Research',
  'Startup',
  'Design',
  'Public Speaking',
  'Project Challenge',
]);

const QueryParserSchema = z.object({
  originalQuery: z.string(),
  goal: z.string(),
  intent: z.string(),
  domains: z.array(z.string()),
  opportunityTypes: z.array(OpportunityTypesEnum),
  hardConstraints: z.array(z.string()),
  softPreferences: z.array(z.string()),
  flexibleConstraints: z.array(z.string()),
  negativeConstraints: z.array(z.string()),
  eligibility: z.object({
    year: z.string().nullable().optional(),
    degree: z.string().nullable().optional(),
    department: z.string().nullable().optional(),
  }),
  location: z.string().nullable().optional(),
  mode: z.enum(['ONLINE', 'OFFLINE', 'HYBRID', 'ANY']).nullable().optional(),
  budgetMax: z.number().nullable().optional(),
  dateRange: z.enum(['THIS_WEEKEND', 'NEXT_WEEKEND', 'THIS_MONTH', 'ANYTIME']).nullable().optional(),
  skillLevel: z.enum(['Beginner', 'Intermediate', 'Advanced', 'All Levels']).nullable().optional(),
});

export async function parseUserQuery(
  rawQuery: string,
  userProfile?: any
): Promise<SearchQueryModel> {
  return (await parseUserQueryWithSource(rawQuery, userProfile)).parsed;
}

export async function parseUserQueryWithSource(
  rawQuery: string,
  userProfile?: any
): Promise<{ parsed: SearchQueryModel; provider: 'openai' | 'deterministic' }> {

  // This parser runs only on the server. Never pass the API key to a client component.
  const apiKey = process.env.OPENAI_API_KEY;
  if (apiKey) {
    try {
      // Call LLM API (if configured)
      const parsed = await callLlmParser(rawQuery, userProfile);
      if (parsed) return { parsed, provider: 'openai' };
    } catch (err) {
      console.warn('LLM parsing failed, falling back to deterministic parser:', err);
    }
  }

  // Deterministic robust parser logic
  return { parsed: parseQueryDeterministically(rawQuery, userProfile), provider: 'deterministic' };
}

export function parseQueryDeterministically(
  rawQuery: string,
  userProfile?: any
): SearchQueryModel {
  const lower = rawQuery.toLowerCase();

  // 1. Extract Goal & Intent
  let goal = rawQuery;
  let intent = 'Find relevant student growth opportunities';

  if (lower.includes('practical ai experience') || lower.includes('ai experience')) {
    goal = 'Build practical AI experience for internships';
    intent = 'Gain hands-on AI project experience';
  } else if (lower.includes('cybersecurity')) {
    goal = 'Learn cybersecurity and ethical hacking';
    intent = 'Hands-on security exercises and CTF challenges';
  } else if (lower.includes('portfolio') || lower.includes('build my portfolio')) {
    goal = 'Build project portfolio for resume';
    intent = 'Create showcaseable projects with team collaboration';
  } else if (lower.includes('public speaking') || lower.includes('presentation')) {
    goal = 'Improve public speaking & technical pitching';
    intent = 'Deliver tech presentations and receive feedback';
  } else if (lower.includes('startup') || lower.includes('entrepreneurship')) {
    goal = 'Explore startup & venture building';
    intent = 'Validate business ideas and build pitch prototypes';
  } else if (lower.includes('research')) {
    goal = 'Gain research exposure & publication';
    intent = 'Present academic posters and publish research papers';
  }

  // 2. Domains
  const domains: string[] = [];
  if (lower.includes('ai') || lower.includes('ml') || lower.includes('genai') || lower.includes('machine learning')) {
    domains.push('AI/ML');
  }
  if (lower.includes('cybersecurity') || lower.includes('hacking') || lower.includes('security')) {
    domains.push('Cybersecurity');
  }
  if (lower.includes('web') || lower.includes('fullstack') || lower.includes('next.js')) {
    domains.push('Web Dev');
  }
  if (lower.includes('design') || lower.includes('ui') || lower.includes('ux')) {
    domains.push('Design');
  }
  if (lower.includes('startup') || lower.includes('business')) {
    domains.push('Entrepreneurship');
  }
  if (lower.includes('research') || lower.includes('academic')) {
    domains.push('Research');
  }
  if (lower.includes('speaking') || lower.includes('pitch')) {
    domains.push('Public Speaking');
  }
  if (domains.length === 0) domains.push('Technology');

  // 3. Opportunity Types (explicit vs implicit)
  const opportunityTypes: OpportunityType[] = [];
  if (lower.includes('hackathon') || lower.includes('buildathon')) opportunityTypes.push('Hackathon');
  if (lower.includes('workshop') || lower.includes('bootcamp')) opportunityTypes.push('Workshop');
  if (lower.includes('competition') || lower.includes('contest') || lower.includes('ctf')) opportunityTypes.push('Competition');
  if (lower.includes('internship')) opportunityTypes.push('Internship');
  if (lower.includes('open source') || lower.includes('sprint')) opportunityTypes.push('Open Source');
  if (lower.includes('research')) opportunityTypes.push('Research');
  if (lower.includes('startup')) opportunityTypes.push('Startup');
  if (lower.includes('design')) opportunityTypes.push('Design');
  if (lower.includes('speaking')) opportunityTypes.push('Public Speaking');
  if (lower.includes('project')) opportunityTypes.push('Project Challenge');

  if (opportunityTypes.length === 0) {
    // Default expansion based on goal
    if (domains.includes('AI/ML')) {
      opportunityTypes.push('Hackathon', 'Project Challenge', 'Competition', 'Open Source', 'Workshop');
    } else {
      opportunityTypes.push('Hackathon', 'Competition', 'Workshop');
    }
  }

  // 4. Hard & Negative Constraints
  const hardConstraints: string[] = [];
  const negativeConstraints: string[] = [];
  const softPreferences: string[] = [];
  const flexibleConstraints: string[] = [];

  // Negative constraints (e.g. "don't show workshops", "exclude paid events")
  if (lower.includes("don't show workshop") || lower.includes('do not show workshop') || lower.includes("no workshop") || lower.includes("exclude workshop")) {
    negativeConstraints.push('exclude_workshops');
    hardConstraints.push('Exclude Workshops');
  }
  if (lower.includes("no internship") || lower.includes("don't show internship") || lower.includes('do not show internship')) {
    negativeConstraints.push('exclude_internships');
    hardConstraints.push('Exclude Internships');
  }

  // Budget extraction
  let budgetMax: number | null = null;
  if (lower.includes('free') || lower.includes('zero cost') || lower.includes('₹0')) {
    budgetMax = 0;
    hardConstraints.push('Budget: Free (₹0)');
  } else {
    const budgetMatch = lower.match(/(?:budget|under|below|within|<=|<= |max)\s*(?:of)?\s*₹?\s*(\d+)/i) ||
                        lower.match(/₹\s*(\d+)/i);
    if (budgetMatch && budgetMatch[1]) {
      budgetMax = parseInt(budgetMatch[1], 10);
      hardConstraints.push(`Budget ≤ ₹${budgetMax}`);
    }
  }

  // Skill level
  let skillLevel: SkillLevel | null = null;
  if (lower.includes('beginner') || lower.includes('novice') || lower.includes('first year') || lower.includes('starter')) {
    skillLevel = 'Beginner';
    hardConstraints.push('Beginner Friendly');
  } else if (lower.includes('intermediate')) {
    skillLevel = 'Intermediate';
    hardConstraints.push('Intermediate Level');
  } else if (lower.includes('advanced')) {
    skillLevel = 'Advanced';
    hardConstraints.push('Advanced Level');
  }

  // Date availability
  let dateRange: SearchQueryModel['dateRange'] = null;
  if (lower.includes('next weekend')) {
    dateRange = 'NEXT_WEEKEND';
    hardConstraints.push('Next Weekend');
  } else if (lower.includes('this weekend') || lower.includes('weekend') || lower.includes('saturday') || lower.includes('sunday')) {
    dateRange = 'THIS_WEEKEND';
    hardConstraints.push('Available Weekend');
  } else if (lower.includes('this month')) {
    dateRange = 'THIS_MONTH';
    hardConstraints.push('This Month');
  }

  // Location & Mode
  let mode: EventMode | 'ANY' | null = null;
  let location: string | null = null;

  if (lower.includes('online') || lower.includes('virtual') || lower.includes('remote')) {
    mode = 'ONLINE';
    hardConstraints.push('Mode: Online');
  } else if (lower.includes('offline') || lower.includes('in-person') || lower.includes('on-site')) {
    mode = 'OFFLINE';
    hardConstraints.push('Mode: Offline');
  }

  if (lower.includes('coimbatore')) {
    location = 'Coimbatore';
    hardConstraints.push('Location: Coimbatore');
  } else if (lower.includes('chennai')) {
    location = 'Chennai';
    hardConstraints.push('Location: Chennai');
  } else if (lower.includes('bengaluru') || lower.includes('bangalore')) {
    location = 'Bengaluru';
    hardConstraints.push('Location: Bengaluru');
  }

  // User Profile defaults if available
  const yearMatch = lower.match(/(?:1st|first|2nd|second|3rd|third|4th|fourth|final)\s*year/);
  const inferredYear = yearMatch?.[0].includes('first') || yearMatch?.[0].includes('1st') ? '1'
    : yearMatch?.[0].includes('second') || yearMatch?.[0].includes('2nd') ? '2'
    : yearMatch?.[0].includes('third') || yearMatch?.[0].includes('3rd') ? '3'
    : yearMatch?.[0].includes('fourth') || yearMatch?.[0].includes('4th') || yearMatch?.[0].includes('final') ? '4'
    : undefined;
  const degreeMatch = lower.match(/\b(b\.?(?:tech|e|sc|ca)|m\.?(?:tech|sc|ca))\b/i);
  const eligibility = {
    year: inferredYear || (userProfile?.yearOfStudy ? String(userProfile.yearOfStudy) : null),
    degree: degreeMatch ? degreeMatch[1].replace(/\s/g, '').replace(/^btech$/i, 'B.Tech').replace(/^be$/i, 'B.E.') : (userProfile?.degree || null),
    department: userProfile?.department || null,
  };

  return {
    originalQuery: rawQuery,
    goal,
    intent,
    domains,
    opportunityTypes,
    hardConstraints,
    softPreferences,
    flexibleConstraints,
    negativeConstraints,
    eligibility,
    location,
    mode,
    budgetMax,
    dateRange,
    skillLevel,
    confidence: {
      goalConfidence: 0.95,
      intentConfidence: 0.92,
      constraintConfidence: 0.98,
    },
  };
}

async function callLlmParser(rawQuery: string, userProfile?: any): Promise<SearchQueryModel | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;

  const client = new OpenAI({ apiKey });
  const fallback = parseQueryDeterministically(rawQuery, userProfile);
  const completion = await client.chat.completions.create({
    model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    temperature: 0.1,
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: `You are the intent parser for a student opportunity discovery product. Convert the user's request into JSON only. Do not invent eligibility, dates, fees, locations, or events. Use null when a value is unknown.\n\nReturn exactly these fields: goal (string), intent (string), domains (string array), opportunityTypes (array containing only Hackathon, Workshop, Competition, Internship, Open Source, Research, Startup, Design, Public Speaking, Project Challenge), hardConstraints (string array), softPreferences (string array), flexibleConstraints (string array), negativeConstraints (string array), eligibility ({year: string|null, degree: string|null, department: string|null}), location (string|null), mode (ONLINE|OFFLINE|HYBRID|ANY|null), budgetMax (number|null), dateRange (THIS_WEEKEND|NEXT_WEEKEND|THIS_MONTH|ANYTIME|null), skillLevel (Beginner|Intermediate|Advanced|All Levels|null).`,
      },
      {
        role: 'user',
        content: JSON.stringify({ query: rawQuery, profile: userProfile ?? null }),
      },
    ],
  });

  const content = completion.choices[0]?.message.content;
  if (!content) return null;

  const parsed = QueryParserSchema.safeParse({
    ...JSON.parse(content),
    originalQuery: rawQuery,
  });
  if (!parsed.success) return null;

  return {
    ...parsed.data,
    // The provider supplies the interpretation; confidence scores are deliberately
    // conservative because this application does not yet run calibrated evals.
    confidence: {
      goalConfidence: 0.8,
      intentConfidence: 0.8,
      constraintConfidence: 0.8,
    },
  };
}
