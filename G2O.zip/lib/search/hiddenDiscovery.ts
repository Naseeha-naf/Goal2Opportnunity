import { RankedOpportunityResult } from '@/types/opportunity';
import { SearchQueryModel } from '@/types/discovery';

export function findHiddenOpportunities(
  results: RankedOpportunityResult[],
  query: SearchQueryModel
): RankedOpportunityResult | null {
  if (!results || results.length === 0) return null;

  // A hidden opportunity must be from a category the user did not explicitly name.
  // Do not label an ordinary ranked result as “hidden discovery”.
  const requested = query.originalQuery.toLowerCase();
  const explicitlyRequestedType = (type: string) => {
    const terms: Record<string, string[]> = {
      Hackathon: ['hackathon', 'buildathon'], Workshop: ['workshop', 'bootcamp'], Competition: ['competition', 'contest', 'ctf'],
      Internship: ['internship'], 'Open Source': ['open source', 'sprint'], Research: ['research'], Startup: ['startup'],
      Design: ['design', 'ui', 'ux'], 'Public Speaking': ['public speaking', 'speaking', 'pitch'], 'Project Challenge': ['project challenge'],
    };
    return (terms[type] || [type.toLowerCase()]).some((term) => requested.includes(term));
  };

  const hiddenCandidate = results.find((res) => {
    const oppType = res.opportunity.opportunityType;
    return !explicitlyRequestedType(oppType) && res.totalScore >= 70;
  });

  if (!hiddenCandidate) return null;

  return {
    ...hiddenCandidate,
    isHiddenMatch: true,
    hiddenReason: `Different category discovered: you did not explicitly request a ${hiddenCandidate.opportunity.opportunityType}, but its stored ${hiddenCandidate.opportunity.domain} domain and validated match signals satisfy your stated goal.`
  };
}
