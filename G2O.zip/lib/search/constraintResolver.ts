import { OpportunityItem } from '@/types/opportunity';
import { SearchQueryModel, ConstraintResolutionResult, ConstraintRelaxationOption } from '@/types/discovery';
import { executeHybridSearch } from './hybridSearch';

export function applyApprovedRelaxation(query: SearchQueryModel, option: ConstraintRelaxationOption): SearchQueryModel {
  if (option.type === 'MODE' && option.newMode) return { ...query, mode: option.newMode };
  if (option.type === 'LOCATION') return { ...query, location: null };
  if (option.type === 'BUDGET' && option.newBudgetMax !== undefined) return { ...query, budgetMax: option.newBudgetMax };
  if (option.type === 'DATE') return { ...query, dateRange: 'ANYTIME' };
  return query;
}

export function resolveConstraintConflict(
  allOpportunities: OpportunityItem[],
  query: SearchQueryModel
): ConstraintResolutionResult {
  const failingConstraints = [...query.hardConstraints];
  const conflictReason = 'No verified opportunity satisfies every stated hard constraint. Each suggestion below is measured by changing exactly one constraint.';

  // Select the smallest *measured* relaxation. Each candidate was executed
  // against the same dataset above; no fallback counts are invented.
  const options: ConstraintRelaxationOption[] = [];

  if (query.mode === 'OFFLINE') {
    const modeRes = executeHybridSearch(allOpportunities, { ...query, mode: 'ONLINE', hardConstraints: query.hardConstraints.filter((c) => !c.toLowerCase().includes('offline')) });
    if (modeRes.exactMatches.length > 0) options.push({
      type: 'MODE', label: 'Allow Online or Hybrid Events', description: 'Changes only the offline requirement; all other requirements remain active.',
      recoveredCount: modeRes.exactMatches.length, newMode: 'ONLINE',
    });
  }

  if (query.location) {
    const locRes = executeHybridSearch(allOpportunities, { ...query, location: null, hardConstraints: query.hardConstraints.filter((c) => !c.toLowerCase().includes('location')) });
    if (locRes.exactMatches.length > 0) options.push({
      type: 'LOCATION', label: 'Remove the location requirement', description: 'Changes only the stated location; all other requirements remain active.', recoveredCount: locRes.exactMatches.length,
    });
  }

  if (query.budgetMax !== null && query.budgetMax !== undefined) {
    const newBudgetMax = query.budgetMax + 300;
    const budgetRes = executeHybridSearch(allOpportunities, { ...query, budgetMax: newBudgetMax, hardConstraints: query.hardConstraints.filter((c) => !c.toLowerCase().includes('budget')) });
    if (budgetRes.exactMatches.length > 0) options.push({
      type: 'BUDGET', label: `Increase Budget by ₹300`, description: `Changes only the budget limit to ₹${newBudgetMax}.`, recoveredCount: budgetRes.exactMatches.length, newBudgetMax,
    });
  }

  if (query.dateRange && query.dateRange !== 'ANYTIME') {
    const dateRes = executeHybridSearch(allOpportunities, { ...query, dateRange: 'ANYTIME', hardConstraints: query.hardConstraints.filter((c) => !c.toLowerCase().includes('weekend')) });
    if (dateRes.exactMatches.length > 0) options.push({
      type: 'DATE', label: 'Remove the date restriction', description: 'Changes only the requested period; all other requirements remain active.', recoveredCount: dateRes.exactMatches.length, newDateRange: 'ANYTIME',
    });
  }

  // A suggestion is added only when changing exactly that one constraint recovers results.
  const cost: Record<ConstraintRelaxationOption['type'], number> = { MODE: 1, LOCATION: 2, DATE: 2, BUDGET: 3, TYPE: 4 };
  options.sort((a, b) => cost[a.type] - cost[b.type] || b.recoveredCount - a.recoveredCount);
  const recommended = options[0] ?? {
    type: 'TYPE' as const,
    label: 'Broaden opportunity types',
    description: 'No single safe relaxation produces a feasible match. Keep your requirements or broaden the goal.',
    recoveredCount: 0,
  };
  const alternatives = options.slice(1);

  return {
    conflictReason,
    failingConstraints,
    blockingConstraints: options.length ? options.map((option) => option.label) : failingConstraints,
    recommendedRelaxation: recommended,
    alternativeRelaxations: alternatives,
    recoveredResultCount: recommended.recoveredCount,
  };
}
