import { OpportunityItem, RankedOpportunityResult } from '@/types/opportunity';
import { SearchQueryModel } from '@/types/discovery';
import { rankOpportunities } from './ranker';

export interface HybridSearchResult {
  exactMatches: RankedOpportunityResult[];
  hardFilterViolationCount: number;
  totalCandidatesEvaluated: number;
  query: SearchQueryModel;
}

export function executeHybridSearch(
  allOpportunities: OpportunityItem[],
  query: SearchQueryModel,
  semanticScores: Map<string, number> = new Map()
): HybridSearchResult {
  let evaluated = 0;
  let hardFilterViolations = 0;

  // Step 1: Hard Filter Enforcement (Must NEVER be violated)
  const feasibleOpportunities = allOpportunities.filter((opp) => {
    evaluated++;

    const searchText = `${opp.domain} ${opp.title} ${opp.description} ${opp.skills.join(' ')}`.toLowerCase();
    const domainMatch = query.domains.some((domain) => searchText.includes(domain.toLowerCase().replace('ai/ml', 'ai')));
    const typeMatch = query.opportunityTypes.includes(opp.opportunityType);
    const semanticMatch = (semanticScores.get(opp.id) ?? 0) >= 0.55;
    // A candidate may enter through lexical/type relevance OR real semantic similarity.
    // Hard suitability constraints below remain mandatory in every case.
    if (!domainMatch && !typeMatch && !semanticMatch) return false;

    // 1. Negative Constraints Check (Strict Exclusions)
    if (query.negativeConstraints.length > 0) {
      if (query.negativeConstraints.includes('exclude_workshops') && opp.opportunityType === 'Workshop') {
        hardFilterViolations++;
        return false;
      }
      if (query.negativeConstraints.includes('exclude_internships') && opp.opportunityType === 'Internship') {
        hardFilterViolations++;
        return false;
      }
    }

    // 2. Hard Budget Constraint (Fee <= budgetMax)
    if (query.budgetMax !== null && query.budgetMax !== undefined) {
      if (opp.fee > query.budgetMax) {
        hardFilterViolations++;
        return false;
      }
    }

    // 3. Mode Constraint (If user specified strict mode, e.g. OFFLINE in Coimbatore)
    if (query.mode && query.mode !== 'ANY') {
      if (query.mode === 'OFFLINE' && opp.mode === 'ONLINE') {
        hardFilterViolations++;
        return false;
      }
      if (query.mode === 'ONLINE' && opp.mode === 'OFFLINE') {
        hardFilterViolations++;
        return false;
      }
    }

    // 4. Location Constraint (If specified)
    if (query.location && query.mode === 'OFFLINE') {
      const oppLoc = (opp.location + ' ' + opp.city).toLowerCase();
      if (!oppLoc.includes(query.location.toLowerCase())) {
        hardFilterViolations++;
        return false;
      }
    }

    // 5. Skill Level (If strict Beginner requirement, filter out Advanced)
    if (query.skillLevel === 'Beginner' && opp.difficulty === 'Advanced') {
      hardFilterViolations++;
      return false;
    }

    // Eligibility is feasibility, not a soft ranking signal.
    if (query.eligibility?.year && !opp.eligibleYears.includes(query.eligibility.year) && !opp.eligibleYears.includes('UG')) {
      hardFilterViolations++;
      return false;
    }
    if (query.eligibility?.degree && !opp.eligibleDegrees.some((degree) => degree === 'Any' || degree.toLowerCase() === query.eligibility.degree!.toLowerCase())) {
      hardFilterViolations++;
      return false;
    }

    // Deadline must be open, and date constraints must compare real dates.
    const now = new Date();
    if (new Date(opp.registrationDeadline) < now) return false;
    if (query.dateRange === 'THIS_WEEKEND' || query.dateRange === 'NEXT_WEEKEND') {
      const start = new Date(opp.startDate);
      const firstSaturday = new Date(now);
      firstSaturday.setHours(0, 0, 0, 0);
      firstSaturday.setDate(now.getDate() + ((6 - now.getDay() + 7) % 7));
      const weekendStart = new Date(firstSaturday);
      if (query.dateRange === 'NEXT_WEEKEND') weekendStart.setDate(weekendStart.getDate() + 7);
      const weekendEnd = new Date(weekendStart);
      weekendEnd.setDate(weekendEnd.getDate() + 2);
      if (start < weekendStart || start >= weekendEnd) return false;
    }

    return true;
  });

  // Step 2 & 3: Rank Feasible Candidates
  const ranked = rankOpportunities(feasibleOpportunities, query, semanticScores);

  return {
    exactMatches: ranked,
    hardFilterViolationCount: hardFilterViolations,
    totalCandidatesEvaluated: evaluated,
    query,
  };
}
