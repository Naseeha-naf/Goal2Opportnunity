import { OpportunityItem, RankedOpportunityResult, MatchScoreBreakdown } from '@/types/opportunity';
import { SearchQueryModel } from '@/types/discovery';

export function calculateMatchScore(
  opp: OpportunityItem,
  query: SearchQueryModel,
  semanticSimilarity?: number
): RankedOpportunityResult {
  const reasons: string[] = [];
  const mismatches: string[] = [];

  // 1. Goal Relevance (35%): real vector similarity when available,
  // with the existing lexical/domain signals as a deterministic fallback.
  let goalRelevance = semanticSimilarity !== undefined
    ? Math.round(Math.max(0, Math.min(1, semanticSimilarity)) * 100)
    : 50;
  const goalLower = query.goal.toLowerCase();
  const descLower = (opp.title + ' ' + opp.description + ' ' + opp.shortDescription + ' ' + opp.domain).toLowerCase();

  if (semanticSimilarity === undefined) {
    if (query.domains.some((d) => opp.domain.toLowerCase().includes(d.toLowerCase()))) {
      goalRelevance += 30;
    }
    if (goalLower.includes('ai') && descLower.includes('ai')) goalRelevance += 20;
    if (goalLower.includes('cybersecurity') && descLower.includes('cybersecurity')) goalRelevance += 20;
    if (goalLower.includes('portfolio') && (opp.opportunityType === 'Hackathon' || opp.opportunityType === 'Project Challenge')) goalRelevance += 20;
    if (goalLower.includes('speaking') && opp.opportunityType === 'Public Speaking') goalRelevance += 20;
    if (goalLower.includes('startup') && opp.opportunityType === 'Startup') goalRelevance += 20;
    if (goalLower.includes('research') && opp.opportunityType === 'Research') goalRelevance += 20;
  } else {
    reasons.push(`Semantic similarity: ${Math.round(semanticSimilarity * 100)}%`);
  }

  goalRelevance = Math.min(100, goalRelevance);
  reasons.push(`Stored domain: ${opp.domain}; matched against your stated goal`);

  // 2. Intent Relevance (20%)
  let intentRelevance = 60;
  if (opp.shortDescription.toLowerCase().includes('hands-on') || opp.description.toLowerCase().includes('prototype')) {
    intentRelevance += 30;
  }
  if (opp.teamAllowed) intentRelevance += 10;
  intentRelevance = Math.min(100, intentRelevance);

  // 3. Skill Level Match (10%)
  let skillMatch = 100;
  if (query.skillLevel) {
    if (opp.difficulty === query.skillLevel || opp.difficulty === 'All Levels') {
      skillMatch = 100;
      reasons.push(`Stored difficulty: ${opp.difficulty}`);
    } else if (query.skillLevel === 'Beginner' && opp.difficulty === 'Intermediate') {
      skillMatch = 70;
      mismatches.push(`Event is Intermediate level (you prefer Beginner)`);
    } else if (query.skillLevel === 'Beginner' && opp.difficulty === 'Advanced') {
      skillMatch = 40;
      mismatches.push(`Event is Advanced level`);
    }
  } else {
    skillMatch = 90;
  }

  // 4. Budget Fit (10%)
  let budgetMatch = 100;
  if (query.budgetMax !== null && query.budgetMax !== undefined) {
    if (opp.fee <= query.budgetMax) {
      budgetMatch = 100;
      reasons.push(opp.fee === 0 ? `100% Free event` : `₹${opp.fee} fee is within your ₹${query.budgetMax} budget`);
    } else {
      budgetMatch = Math.max(0, 100 - (opp.fee - query.budgetMax) / 10);
      mismatches.push(`Fee ₹${opp.fee} exceeds budget ₹${query.budgetMax}`);
    }
  } else {
    budgetMatch = opp.fee === 0 ? 100 : 90;
  }

  // 5. Eligibility Match (10%)
  let eligibilityMatch = 100;
  if (query.eligibility?.degree) {
    const isDegEligible = opp.eligibleDegrees.some(
      (d) => d === 'Any' || d.toLowerCase().includes(query.eligibility.degree!.toLowerCase())
    );
    if (isDegEligible) {
      reasons.push(`Stored eligibility: ${opp.eligibilityText}`);
    } else {
      eligibilityMatch = 70;
    }
  }

  // 6. Availability / Date Match (5%)
  let availabilityMatch = 90;
  if (query.dateRange === 'THIS_WEEKEND') {
    availabilityMatch = 100;
    reasons.push(`Fits weekend schedule`);
  }

  // 7. Preference Match (5%)
  let preferenceMatch = 90;
  if (query.mode && query.mode !== 'ANY') {
    if (opp.mode === query.mode || opp.mode === 'HYBRID') {
      preferenceMatch = 100;
    } else {
      preferenceMatch = 50;
      mismatches.push(`Preferred ${query.mode} (Event is ${opp.mode})`);
    }
  }

  // 8. Quality / Freshness (5%)
  const freshnessScore = opp.isVerified ? 100 : 80;

  // Weighted sum formula calculation:
  const weightedScore =
    goalRelevance * 0.35 +
    intentRelevance * 0.20 +
    skillMatch * 0.10 +
    budgetMatch * 0.10 +
    eligibilityMatch * 0.10 +
    availabilityMatch * 0.05 +
    preferenceMatch * 0.05 +
    freshnessScore * 0.05;

  const totalScore = Math.round(weightedScore);

  const breakdown: MatchScoreBreakdown = {
    goalRelevance: Math.round(goalRelevance),
    intentRelevance: Math.round(intentRelevance),
    skillMatch: Math.round(skillMatch),
    budgetMatch: Math.round(budgetMatch),
    eligibilityMatch: Math.round(eligibilityMatch),
    availabilityMatch: Math.round(availabilityMatch),
    preferenceMatch: Math.round(preferenceMatch),
    freshnessScore: Math.round(freshnessScore),
  };

  return {
    opportunity: opp,
    totalScore,
    breakdown,
    reasons,
    mismatches,
  };
}

export function rankOpportunities(
  opportunities: OpportunityItem[],
  query: SearchQueryModel,
  semanticScores: Map<string, number> = new Map()
): RankedOpportunityResult[] {
  const scored = opportunities.map((opp) => calculateMatchScore(opp, query, semanticScores.get(opp.id)));
  return scored.sort((a, b) => b.totalScore - a.totalScore);
}
