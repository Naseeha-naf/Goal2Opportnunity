import OpenAI from 'openai';
import { Prisma } from '@prisma/client';
import { prisma, toOpportunityItem } from '@/lib/db/prisma';
import { SearchQueryModel } from '@/types/discovery';
import { OpportunityItem } from '@/types/opportunity';

export interface SemanticCandidate {
  opportunity: OpportunityItem;
  similarity: number;
}

type SemanticRow = Record<string, unknown> & {
  semanticSimilarity: number | string;
};

function embeddingClient(): OpenAI | null {
  const apiKey = process.env.OPENAI_API_KEY;
  return apiKey ? new OpenAI({ apiKey }) : null;
}

export function buildOpportunityEmbeddingText(opp: Pick<OpportunityItem, 'title' | 'description' | 'shortDescription' | 'opportunityType' | 'domain' | 'skills'>): string {
  return [
    opp.title,
    opp.shortDescription,
    opp.description,
    `Type: ${opp.opportunityType}`,
    `Domain: ${opp.domain}`,
    `Skills: ${opp.skills.join(', ')}`,
  ].join('\n');
}

export async function createEmbedding(text: string): Promise<number[] | null> {
  const client = embeddingClient();
  if (!client) return null;

  try {
    const response = await client.embeddings.create({
      model: process.env.OPENAI_EMBEDDING_MODEL || 'text-embedding-3-small',
      input: text,
    });
    return response.data[0]?.embedding ?? null;
  } catch {
    // Semantic retrieval is an enhancement, never a single point of failure.
    return null;
  }
}

function vectorLiteral(vector: number[]): string {
  return `[${vector.join(',')}]`;
}

export async function findSemanticCandidates(
  query: SearchQueryModel,
  limit = 50
): Promise<SemanticCandidate[]> {
  const vector = await createEmbedding(`${query.goal}\n${query.intent}\n${query.originalQuery}`);
  if (!vector) return [];

  const clauses: Prisma.Sql[] = [
    Prisma.sql`o."isVerified" = true`,
    Prisma.sql`o."verificationStatus" = 'VERIFIED'`,
    Prisma.sql`o."registrationDeadline" >= NOW()`,
    Prisma.sql`o."embedding" IS NOT NULL`,
  ];

  if (query.budgetMax !== null && query.budgetMax !== undefined) {
    clauses.push(Prisma.sql`o."fee" <= ${query.budgetMax}`);
  }
  if (query.mode === 'ONLINE') {
    clauses.push(Prisma.sql`o."mode" IN ('ONLINE', 'HYBRID')`);
  } else if (query.mode === 'OFFLINE') {
    clauses.push(Prisma.sql`o."mode" IN ('OFFLINE', 'HYBRID')`);
  }
  if (query.location && query.mode === 'OFFLINE') {
    clauses.push(Prisma.sql`(LOWER(o."location") LIKE ${`%${query.location.toLowerCase()}%`} OR LOWER(o."city") LIKE ${`%${query.location.toLowerCase()}%`})`);
  }
  if (query.skillLevel === 'Beginner') {
    clauses.push(Prisma.sql`o."difficulty" <> 'Advanced'`);
  }

  try {
    const rows = await prisma.$queryRaw<SemanticRow[]>(Prisma.sql`
      SELECT o.*, 1 - (o."embedding" <=> CAST(${vectorLiteral(vector)} AS vector)) AS "semanticSimilarity"
      FROM "Opportunity" o
      WHERE ${Prisma.join(clauses, ' AND ')}
      ORDER BY o."embedding" <=> CAST(${vectorLiteral(vector)} AS vector)
      LIMIT ${limit}
    `);

    return rows
      .map((row) => {
        const opportunity = toOpportunityItem(row as never);
        if (!opportunity) return null;
        return {
          opportunity,
          similarity: Math.max(0, Math.min(1, Number(row.semanticSimilarity) || 0)),
        };
      })
      .filter((item): item is SemanticCandidate => item !== null);
  } catch {
    // Allows local/dev environments that have not applied the pgvector migration yet.
    return [];
  }
}

export async function storeOpportunityEmbedding(id: string, text: string): Promise<boolean> {
  const vector = await createEmbedding(text);
  if (!vector) return false;

  try {
    await prisma.$executeRaw(Prisma.sql`
      UPDATE "Opportunity"
      SET "embedding" = CAST(${vectorLiteral(vector)} AS vector)
      WHERE "id" = ${id}
    `);
    return true;
  } catch {
    return false;
  }
}
