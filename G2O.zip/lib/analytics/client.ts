'use client';

export type DiscoveryAnalyticsEvent =
  | 'discovery_search'
  | 'opportunity_opened'
  | 'registration_cta_clicked'
  | 'relaxation_approved';

export function trackDiscoveryEvent(
  name: DiscoveryAnalyticsEvent,
  opportunityId?: string,
  metadata?: Record<string, string | number | boolean | null>,
) {
  const payload = JSON.stringify({ name, opportunityId, metadata });
  // A best-effort event must never interrupt a search or registration action.
  if (typeof navigator !== 'undefined' && 'sendBeacon' in navigator) {
    navigator.sendBeacon('/api/analytics/events', new Blob([payload], { type: 'application/json' }));
    return;
  }
  void fetch('/api/analytics/events', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: payload, keepalive: true,
  }).catch(() => undefined);
}
