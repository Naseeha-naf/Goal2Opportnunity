import { z } from 'zod';

export const opportunityIngestionSchema = z.object({
  sourceId: z.string().trim().min(2).max(100),
  sourceUrl: z.string().url(),
  title: z.string().trim().min(3).max(240),
  description: z.string().trim().max(20_000).default(''),
  organizer: z.string().trim().min(2).max(180),
  opportunityType: z.string().trim().max(80).default('Workshop'),
  domain: z.string().trim().max(100).default('Technology'),
  skills: z.array(z.string().trim().max(80)).default([]),
  difficulty: z.enum(['Beginner', 'Intermediate', 'Advanced', 'All Levels']).default('All Levels'),
  eligibilityText: z.string().trim().max(2_000).default('Eligibility not supplied by source.'),
  eligibleYears: z.array(z.string().trim().max(20)).default([]),
  eligibleDegrees: z.array(z.string().trim().max(80)).default([]),
  registrationUrl: z.string().url().nullable().optional(),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  registrationDeadline: z.coerce.date().nullable().optional(),
  location: z.string().trim().max(240).nullable().optional(),
  mode: z.enum(['ONLINE', 'OFFLINE', 'HYBRID', 'UNKNOWN']).default('UNKNOWN'),
  fee: z.number().finite().min(0).nullable().optional(),
  retrievedAt: z.coerce.date(),
  verificationStatus: z.literal('PENDING_REVIEW'),
}).superRefine((value, ctx) => {
  if (value.endDate < value.startDate) ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'endDate must not precede startDate', path: ['endDate'] });
  if (value.registrationDeadline && value.registrationDeadline > value.startDate) ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'registrationDeadline must be on or before startDate', path: ['registrationDeadline'] });
});

export type IngestedOpportunity = z.infer<typeof opportunityIngestionSchema>;
