'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { OpportunityItem, RankedOpportunityResult } from '@/types/opportunity';
import { SearchQueryModel, ConstraintResolutionResult, ConstraintRelaxationOption } from '@/types/discovery';
import { trackDiscoveryEvent } from '@/lib/analytics/client';

export interface UserProfileData {
  name: string;
  email: string;
  college: string;
  degree: string;
  department: string;
  yearOfStudy: number;
  graduationYear: number;
  city: string;
  interests: string[];
  preferredMode: string;
  preferredLocation: string;
  typicalBudget: number;
  weekendAvailable: boolean;
  teamPreference: string;
  completenessScore: number;
}

const DEFAULT_PROFILE: UserProfileData = {
  name: 'Alex Rivers',
  email: 'alex.rivers@college.edu',
  college: 'PSG College of Technology',
  degree: 'B.E.',
  department: 'Computer Science & Engineering',
  yearOfStudy: 2,
  graduationYear: 2028,
  city: 'Coimbatore',
  interests: ['AI / ML', 'Web Development', 'Open Source', 'Hackathons'],
  preferredMode: 'ANY',
  preferredLocation: 'Coimbatore',
  typicalBudget: 500,
  weekendAvailable: true,
  teamPreference: 'TEAM',
  completenessScore: 85,
};

interface DiscoveryContextType {
  user: { name: string; email: string } | null;
  profile: UserProfileData;
  rawQuery: string;
  parsedQuery: SearchQueryModel | null;
  allOpportunities: OpportunityItem[];
  searchResults: RankedOpportunityResult[];
  hiddenOpportunity: RankedOpportunityResult | null;
  constraintConflict: ConstraintResolutionResult | null;
  savedOpportunityIds: string[];
  isLoading: boolean;
  setRawQuery: (q: string) => void;
  setParsedQuery: (pq: SearchQueryModel) => void;
  executeSearch: (queryStr?: string, approvedRelaxation?: ConstraintRelaxationOption) => Promise<void>;
  updateProfile: (data: Partial<UserProfileData>) => void;
  toggleSaveOpportunity: (id: string) => void;
  signIn: (email: string, name?: string) => void;
  signOut: () => void;
}

const DiscoveryContext = createContext<DiscoveryContextType | undefined>(undefined);

export const DiscoveryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [profile, setProfile] = useState<UserProfileData>(DEFAULT_PROFILE);
  const [rawQuery, setRawQuery] = useState<string>(
    'I want practical AI experience for internships. I’m a beginner, available on weekends, and my budget is under ₹500.'
  );
  const [parsedQuery, setParsedQuery] = useState<SearchQueryModel | null>(null);
  const [allOpportunities, setAllOpportunities] = useState<OpportunityItem[]>([]);
  const [searchResults, setSearchResults] = useState<RankedOpportunityResult[]>([]);
  const [hiddenOpportunity, setHiddenOpportunity] = useState<RankedOpportunityResult | null>(null);
  const [constraintConflict, setConstraintConflict] = useState<ConstraintResolutionResult | null>(null);
  const [savedOpportunityIds, setSavedOpportunityIds] = useState<string[]>(['opp-001']);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Initialize state from local storage if present
  useEffect(() => {
    try {
      const savedQuery = localStorage.getItem('g2o_query');
      if (savedQuery) setRawQuery(savedQuery);
      const savedSaved = localStorage.getItem('g2o_saved');
      if (savedSaved) setSavedOpportunityIds(JSON.parse(savedSaved));
    } catch (e) {
      console.warn('LocalStorage access warning', e);
    }

    // Run initial default search so results are ready
    runSearchInternal(
      'I want practical AI experience for internships. I’m a beginner, available on weekends, and my budget is under ₹500.'
    );
    fetch('/api/auth/me')
      .then((response) => response.ok ? response.json() : null)
      .then((data) => {
        if (data?.user) {
          setUser({ name: data.user.name || data.user.email, email: data.user.email });
          const persisted = data.user.profile;
          if (persisted) {
            let interests: string[] = [];
            try { interests = JSON.parse(persisted.interests || '[]'); } catch { interests = []; }
            setProfile((current) => ({ ...current, ...persisted, interests, name: data.user.name || current.name, email: data.user.email }));
          }
        }
      })
      .catch(() => undefined);
  }, []);

  const runSearchInternal = async (queryText: string, approvedRelaxation?: ConstraintRelaxationOption) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/discovery/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryText, profile, approvedRelaxation }),
      });
      if (!response.ok) throw new Error('Search service is unavailable');

      const data = await response.json();
      setParsedQuery(data.query);
      setSearchResults(data.results ?? []);
      setAllOpportunities((data.results ?? []).map((result: RankedOpportunityResult) => result.opportunity));
      setHiddenOpportunity(data.hiddenOpportunity ?? null);
      setConstraintConflict(data.conflict ?? null);
      trackDiscoveryEvent('discovery_search', undefined, {
        resultCount: (data.results ?? []).length,
        hiddenOpportunityFound: Boolean(data.hiddenOpportunity),
        recoverySuggested: Boolean(data.conflict),
        recoveryApproved: Boolean(approvedRelaxation),
      });
      if (approvedRelaxation) trackDiscoveryEvent('relaxation_approved', undefined, { constraint: approvedRelaxation.type });
    } finally {
      setIsLoading(false);
    }
  };

  const executeSearch = async (queryStr?: string, approvedRelaxation?: ConstraintRelaxationOption) => {
    const q = queryStr || rawQuery;
    setRawQuery(q);
    try {
      localStorage.setItem('g2o_query', q);
    } catch (e) {}
    await runSearchInternal(q, approvedRelaxation);
  };

  const updateProfile = (data: Partial<UserProfileData>) => {
    const updated = { ...profile, ...data };
    setProfile(updated);
  };

  const toggleSaveOpportunity = (id: string) => {
    setSavedOpportunityIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id];
      try {
        localStorage.setItem('g2o_saved', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const signIn = (email: string, name?: string) => {
    setUser({ email, name: name || email.split('@')[0] });
  };

  const signOut = () => {
    setUser(null);
  };

  return (
    <DiscoveryContext.Provider
      value={{
        user,
        profile,
        rawQuery,
        parsedQuery,
        allOpportunities,
        searchResults,
        hiddenOpportunity,
        constraintConflict,
        savedOpportunityIds,
        isLoading,
        setRawQuery,
        setParsedQuery,
        executeSearch,
        updateProfile,
        toggleSaveOpportunity,
        signIn,
        signOut,
      }}
    >
      {children}
    </DiscoveryContext.Provider>
  );
};

export function useDiscovery() {
  const context = useContext(DiscoveryContext);
  if (!context) {
    throw new Error('useDiscovery must be used within a DiscoveryProvider');
  }
  return context;
}
