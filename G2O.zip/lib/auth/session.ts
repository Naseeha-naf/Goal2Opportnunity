import { SignJWT, jwtVerify } from 'jose';

const secret = new TextEncoder().encode(process.env.AUTH_SECRET || 'replace-this-before-production');
const issuer = 'goal2opportunity';

export async function createSession(user: { id: string; email: string; name: string | null }) {
  return new SignJWT({ email: user.email, name: user.name })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(issuer)
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);
}

export async function readSession(token?: string) {
  if (!token) return null;
  try { return (await jwtVerify(token, secret, { issuer })).payload; } catch { return null; }
}
