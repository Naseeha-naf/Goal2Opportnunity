import { Prisma } from '@prisma/client';
import { prisma } from './client';
export { prisma };
import { OpportunityItem } from '@/types/opportunity';
import { SearchQueryModel } from '@/types/discovery';

function parseList(value: string) {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch { return []; }
}

export function toOpportunityItem(record: any): OpportunityItem | null {
  if (!record) return null;
  return {
    id: record.id, title: record.title, slug: record.slug, description: record.description,
    shortDescription: record.shortDescription, organizer: record.organizer,
    opportunityType: record.opportunityType as OpportunityItem['opportunityType'], domain: record.domain,
    skills: parseList(record.skills), difficulty: record.difficulty as OpportunityItem['difficulty'],
    eligibilityText: record.eligibilityText, eligibleYears: parseList(record.eligibleYears), eligibleDegrees: parseList(record.eligibleDegrees),
    location: record.location, city: record.city, state: record.state, country: record.country,
    mode: record.mode as OpportunityItem['mode'], fee: record.fee, currency: record.currency,
    startDate: record.startDate.toISOString(), endDate: record.endDate.toISOString(), registrationDeadline: record.registrationDeadline.toISOString(),
    teamAllowed: record.teamAllowed, teamMin: record.teamMin, teamMax: record.teamMax, prize: record.prize,
    registrationUrl: record.registrationUrl, sourceUrl: record.sourceUrl, isVerified: record.isVerified,
    createdAt: record.createdAt.toISOString(), updatedAt: record.updatedAt.toISOString(),
  };
}

// Only reviewed, verified database records may reach the student search experience.
export async function getOpportunitiesFromDb(): Promise<OpportunityItem[]> {
  const records = await prisma.opportunity.findMany({
    where: { isVerified: true, verificationStatus: 'VERIFIED', registrationDeadline: { gte: new Date() } },
    orderBy: [{ registrationDeadline: 'asc' }, { createdAt: 'desc' }],
    take: 100,
  });
  return records.map((record) => toOpportunityItem(record)).filter((record): record is OpportunityItem => record !== null);
}


// Lexical + structured candidate retrieval happens in PostgreSQL before the
// existing hard-feasibility validation/ranking layer. Semantic candidates are
// retrieved separately through pgvector and merged by the search route.
export async function getLexicalCandidatesFromDb(
  query: SearchQueryModel,
  limit = 100
): Promise<OpportunityItem[]> {
  const structuredAnd: Prisma.OpportunityWhereInput[] = [
    { isVerified: true },
    { verificationStatus: 'VERIFIED' },
    { registrationDeadline: { gte: new Date() } },
  ];

  if (query.budgetMax !== null && query.budgetMax !== undefined) {
    structuredAnd.push({ fee: { lte: query.budgetMax } });
  }
  if (query.mode === 'ONLINE') {
    structuredAnd.push({ mode: { in: ['ONLINE', 'HYBRID'] } });
  } else if (query.mode === 'OFFLINE') {
    structuredAnd.push({ mode: { in: ['OFFLINE', 'HYBRID'] } });
  }
  if (query.location && query.mode === 'OFFLINE') {
    structuredAnd.push({
      OR: [
        { location: { contains: query.location, mode: 'insensitive' } },
        { city: { contains: query.location, mode: 'insensitive' } },
      ],
    });
  }
  if (query.skillLevel === 'Beginner') {
    structuredAnd.push({ difficulty: { not: 'Advanced' } });
  }

  const stopWords = new Set(['want', 'need', 'find', 'looking', 'for', 'with', 'and', 'the', 'this', 'that', 'student', 'opportunity']);
  const goalTerms = Array.from(new Set(
    `${query.goal} ${query.intent}`
      .toLowerCase()
      .split(/[^a-z0-9+#.]+/)
      .filter((term) => term.length >= 3 && !stopWords.has(term))
  )).slice(0, 8);

  const relevanceOr: Prisma.OpportunityWhereInput[] = [];
  if (query.opportunityTypes.length) relevanceOr.push({ opportunityType: { in: query.opportunityTypes } });
  for (const domain of query.domains) {
    relevanceOr.push({ domain: { contains: domain.replace('AI/ML', 'AI'), mode: 'insensitive' } });
  }
  for (const term of goalTerms) {
    relevanceOr.push({ title: { contains: term, mode: 'insensitive' } });
    relevanceOr.push({ description: { contains: term, mode: 'insensitive' } });
    relevanceOr.push({ skills: { contains: term, mode: 'insensitive' } });
  }
  if (relevanceOr.length) structuredAnd.push({ OR: relevanceOr });

  const records = await prisma.opportunity.findMany({
    where: { AND: structuredAnd },
    orderBy: [{ registrationDeadline: 'asc' }, { createdAt: 'desc' }],
    take: limit,
  });
  return records.map((record) => toOpportunityItem(record)).filter((record): record is OpportunityItem => record !== null);
}

export async function getOpportunityByIdFromDb(id: string): Promise<OpportunityItem | null> {
  const record = await prisma.opportunity.findFirst({
    where: { AND: [{ isVerified: true }, { verificationStatus: 'VERIFIED' }, { OR: [{ id }, { slug: id }] }] },
  });
  return toOpportunityItem(record);
}
