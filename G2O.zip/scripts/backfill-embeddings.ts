import { prisma, toOpportunityItem } from '../lib/db/prisma';
import { buildOpportunityEmbeddingText, storeOpportunityEmbedding } from '../lib/search/semanticSearch';

async function main() {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is required to generate semantic embeddings.');
  }

  const records = await prisma.opportunity.findMany({
    where: {
      isVerified: true,
      verificationStatus: 'VERIFIED',
      registrationDeadline: { gte: new Date() },
    },
    orderBy: { updatedAt: 'desc' },
  });

  let updated = 0;
  for (const record of records) {
    const opp = toOpportunityItem(record);
    if (!opp) continue;
    const ok = await storeOpportunityEmbedding(record.id, buildOpportunityEmbeddingText(opp));
    if (ok) {
      updated++;
      console.log(`Embedded: ${record.title}`);
    } else {
      console.warn(`Skipped: ${record.title}`);
    }
  }

  console.log(`Completed embeddings for ${updated}/${records.length} verified opportunities.`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
