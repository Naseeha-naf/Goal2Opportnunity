import { createRequire } from "node:module";
import fs from "node:fs/promises";

const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const sourcePath = process.argv[2] || "event_opportunities_2026-09-02.xlsx";
const rows = JSON.parse(await fs.readFile("data/event_opportunities_2026-09-02.json", "utf8"));
const headers = rows[0].map(String);
const records = rows.slice(1).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index]])));

const clean = (value) => String(value ?? "").trim();
const slugify = (value) => clean(value).toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
const dateOr = (value, fallback) => {
  const date = value instanceof Date ? value : new Date(clean(value));
  return Number.isNaN(date.getTime()) ? fallback : date;
};
const inferType = (type) => {
  const value = clean(type).toLowerCase();
  if (value.includes("hack")) return "Hackathon";
  if (value.includes("workshop") || value.includes("seminar") || value.includes("webinar")) return "Workshop";
  if (value.includes("intern")) return "Internship";
  if (value.includes("research")) return "Research";
  if (value.includes("startup") || value.includes("business") || value.includes("entrepreneur")) return "Startup";
  if (value.includes("design")) return "Design";
  if (value.includes("speaker") || value.includes("debate") || value.includes("public speaking")) return "Public Speaking";
  if (value.includes("project") || value.includes("coding")) return "Project Challenge";
  return "Competition";
};
const inferDomain = (title, type) => {
  const value = `${clean(title)} ${clean(type)}`.toLowerCase();
  if (/ai|machine learning|data science|agent|genai/.test(value)) return "AI/ML";
  if (/cyber|ctf|security/.test(value)) return "Cybersecurity";
  if (/robot/.test(value)) return "Robotics";
  if (/iot|embedded/.test(value)) return "IoT";
  if (/web|coding|software|code/.test(value)) return "Web Dev";
  if (/design|ui|ux/.test(value)) return "Design";
  if (/startup|business|innovation|entrepreneur/.test(value)) return "Entrepreneurship";
  return "Open Source";
};
const parseFee = (value) => {
  const text = clean(value);
  if (!text || /free|nil|none/i.test(text)) return 0;
  const number = Number(text.replace(/[^0-9.]/g, ""));
  return Number.isFinite(number) ? number : 0;
};
const parseLocation = (value, mode) => {
  if (mode === "ONLINE") return { location: "Online", city: "Online", state: "Remote" };
  const parts = clean(value).split(",").map((part) => part.trim()).filter(Boolean);
  return { location: clean(value) || "India", city: parts[0] || "India", state: parts[1] || "India" };
};
const parseTeams = (eligibility) => {
  const text = clean(eligibility);
  const range = text.match(/teams?\s*(\d+)\s*[–-]\s*(\d+)/i);
  if (range) return { teamAllowed: true, teamMin: Number(range[1]), teamMax: Number(range[2]) };
  if (/individual/i.test(text)) return { teamAllowed: false, teamMin: 1, teamMax: 1 };
  return { teamAllowed: true, teamMin: 1, teamMax: 4 };
};

let imported = 0;
for (const row of records) {
  const title = clean(row["Event / Opportunity"]);
  if (!title) continue;
  const rawMode = clean(row.Mode).toUpperCase();
  const mode = rawMode.includes("ONLINE") ? "ONLINE" : rawMode.includes("HYBRID") ? "HYBRID" : "OFFLINE";
  const endDate = dateOr(row["End Date / Event Date"], dateOr(row["Start Date"], dateOr(row.Deadline, new Date("2026-12-31T23:59:59Z"))));
  const startDate = dateOr(row["Start Date"], endDate);
  const registrationDeadline = dateOr(row.Deadline, startDate);
  const location = parseLocation(row.Location, mode);
  const teams = parseTeams(row.Eligibility);
  const originalType = clean(row.Type) || "Event";
  const opportunityType = inferType(originalType);
  const domain = inferDomain(title, originalType);
  const sourceUrl = clean(row["Source URL"]);
  const data = {
    title,
    slug: `xlsx-${slugify(title)}`,
    description: `${title} is a ${originalType} organized by ${clean(row.Organizer) || clean(row.Platform)}. ${clean(row.Eligibility) ? `Eligibility: ${clean(row.Eligibility)}.` : ""} ${clean(row["Prize / Benefits"]) ? `Prize or benefits: ${clean(row["Prize / Benefits"])}.` : ""}`.trim(),
    shortDescription: `${originalType} from ${clean(row.Organizer) || clean(row.Platform)} (${clean(row.Status) || "listed"}).`,
    organizer: clean(row.Organizer) || clean(row.Platform) || "Unknown organizer",
    opportunityType,
    domain,
    skills: JSON.stringify(domain === "AI/ML" ? ["AI/ML", "Problem Solving"] : [domain, "Problem Solving"]),
    difficulty: /beginner/i.test(clean(row.Eligibility)) ? "Beginner" : "All Levels",
    eligibilityText: clean(row.Eligibility) || "See event listing for eligibility details.",
    eligibleYears: JSON.stringify(["1", "2", "3", "4", "UG", "PG"]),
    eligibleDegrees: JSON.stringify(["Any"]),
    ...location,
    country: "India",
    mode,
    fee: parseFee(row.Fee),
    currency: "INR",
    startDate,
    endDate: endDate < startDate ? startDate : endDate,
    registrationDeadline,
    ...teams,
    prize: clean(row["Prize / Benefits"]) || null,
    registrationUrl: sourceUrl,
    sourceUrl,
    sourceId: `xlsx-${slugify(clean(row.Platform) || "events")}`,
    retrievedAt: new Date("2026-09-02T00:00:00Z"),
    verificationStatus: "VERIFIED",
    isVerified: true,
  };
  await prisma.opportunity.upsert({ where: { slug: data.slug }, create: data, update: data });
  imported += 1;
}

console.log(`Imported ${imported} verified opportunities from ${sourcePath}`);
await prisma.$disconnect();
