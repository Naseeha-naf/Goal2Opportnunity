import assert from 'node:assert/strict';
import { parseQueryDeterministically } from '../lib/ai/queryParser';
import { executeHybridSearch } from '../lib/search/hybridSearch';
import { findHiddenOpportunities } from '../lib/search/hiddenDiscovery';
import { applyApprovedRelaxation, resolveConstraintConflict } from '../lib/search/constraintResolver';
import { OpportunityItem } from '../types/opportunity';

const future = '2027-10-10T10:00:00.000Z';
const deadline = '2027-10-01T10:00:00.000Z';
const base: Omit<OpportunityItem, 'id' | 'slug' | 'title' | 'opportunityType' | 'fee' | 'mode' | 'eligibleYears' | 'eligibleDegrees' | 'registrationDeadline' | 'startDate'> = {
  description: 'Hands-on AI prototype challenge.', shortDescription: 'Build an AI prototype.', organizer: 'Test Organizer', domain: 'AI/ML', skills: ['Python', 'AI'],
  difficulty: 'Beginner', eligibilityText: 'Open to undergraduate students.', location: 'Online', city: '', state: '', country: 'India', currency: 'INR',
  endDate: '2027-10-11T10:00:00.000Z', teamAllowed: true, teamMin: 1, teamMax: 4, prize: null, registrationUrl: 'https://example.test/register', sourceUrl: 'https://example.test', isVerified: true,
};
const opportunities: OpportunityItem[] = [
  { ...base, id: 'valid', slug: 'valid', title: 'AI Builder Hackathon', opportunityType: 'Hackathon', fee: 0, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'], registrationDeadline: deadline, startDate: future },
  { ...base, id: 'paid', slug: 'paid', title: 'Paid AI Hackathon', opportunityType: 'Hackathon', fee: 1000, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'], registrationDeadline: deadline, startDate: future },
  { ...base, id: 'final-year', slug: 'final-year', title: 'Final Year AI Hackathon', opportunityType: 'Hackathon', fee: 0, mode: 'ONLINE', eligibleYears: ['4'], eligibleDegrees: ['B.Tech'], registrationDeadline: deadline, startDate: future },
  { ...base, id: 'workshop', slug: 'workshop', title: 'AI Workshop', opportunityType: 'Workshop', fee: 0, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'], registrationDeadline: deadline, startDate: future },
  { ...base, id: 'project', slug: 'project', title: 'AI Portfolio Project Challenge', opportunityType: 'Project Challenge', fee: 0, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'], registrationDeadline: deadline, startDate: future },
  { ...base, id: 'expired', slug: 'expired', title: 'Expired AI Hackathon', opportunityType: 'Hackathon', fee: 0, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'], registrationDeadline: '2020-01-01T00:00:00.000Z', startDate: future },
];

function search(text: string) { return executeHybridSearch(opportunities, parseQueryDeterministically(text)); }
function ids(text: string) { return search(text).exactMatches.map((result) => result.opportunity.id); }

const strictQuery = 'Find a free beginner AI hackathon online for 2nd year B.Tech students.';
assert(ids(strictQuery).includes('valid'), 'the valid event must be returned');
assert(!ids(strictQuery).includes('paid'), 'over-budget opportunities must be rejected');
assert(!ids(strictQuery).includes('final-year'), 'ineligible year opportunities must be rejected');
assert(!ids(strictQuery).includes('expired'), 'expired registration deadlines must be rejected');

const exclusions = ids('Find a free beginner AI opportunity online for 2nd year B.Tech students. Do not show workshops.');
assert(!exclusions.includes('workshop'), 'explicit workshop exclusion must be enforced');

const hiddenText = 'Find a free beginner AI hackathon online for 2nd year B.Tech students. Do not show workshops.';
const hiddenQuery = parseQueryDeterministically(hiddenText);
const hidden = findHiddenOpportunities(search(hiddenText).exactMatches, hiddenQuery);
assert(hidden, 'a genuinely cross-category candidate should be discovered');
assert.equal(hidden.opportunity.opportunityType, 'Project Challenge', 'hidden discovery must not return the explicitly requested Hackathon category');

const zeroQuery = parseQueryDeterministically('Find a free beginner AI hackathon offline in Coimbatore for 2nd year B.Tech students.');
const zeroResult = executeHybridSearch(opportunities, zeroQuery);
assert.equal(zeroResult.exactMatches.length, 0, 'the zero-result test query must genuinely return zero exact matches');
const recovery = resolveConstraintConflict(opportunities, zeroQuery);
assert.equal(recovery.recommendedRelaxation.type, 'MODE', 'the measured mode change should be the smallest useful recovery');
assert(recovery.recoveredResultCount > 0, 'the recommended relaxation must recover real results');
const approvedResult = executeHybridSearch(opportunities, applyApprovedRelaxation(zeroQuery, recovery.recommendedRelaxation));
assert(approvedResult.exactMatches.length > 0, 'approved relaxation must re-run and recover results');

// Hybrid-search integration proof: a candidate with no lexical/type match can
// still enter through semantic similarity, while all hard constraints remain enforced.
const semanticOnly: OpportunityItem = {
  ...base, id: 'semantic-only', slug: 'semantic-only', title: 'Applied ML Build Sprint',
  description: 'Create a deployable machine-learning prototype for a real problem.',
  shortDescription: 'Build and ship a machine-learning project.', organizer: 'Semantic Test',
  domain: 'Machine Learning', skills: ['Python', 'Models'], opportunityType: 'Project Challenge',
  fee: 0, mode: 'ONLINE', eligibleYears: ['2'], eligibleDegrees: ['B.Tech'],
  registrationDeadline: deadline, startDate: future,
};
const semanticQuery = parseQueryDeterministically('Find a free beginner cybersecurity hackathon online for 2nd year B.Tech students.');
const semanticResult = executeHybridSearch([semanticOnly], semanticQuery, new Map([['semantic-only', 0.88]]));
assert.equal(semanticResult.exactMatches[0]?.opportunity.id, 'semantic-only', 'semantic similarity must be able to contribute candidates beyond lexical/type matching');

console.log('PASS: 12 assertion-backed search-engine checks completed.');
