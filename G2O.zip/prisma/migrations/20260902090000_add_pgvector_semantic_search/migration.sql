-- Real semantic retrieval for Goal2Opportunity.
CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE "Opportunity"
ADD COLUMN IF NOT EXISTS "embedding" vector(1536);

-- Frequently used verified-search filters.
CREATE INDEX IF NOT EXISTS "Opportunity_verified_deadline_idx"
ON "Opportunity" ("isVerified", "verificationStatus", "registrationDeadline");

CREATE INDEX IF NOT EXISTS "Opportunity_mode_city_fee_idx"
ON "Opportunity" ("mode", "city", "fee");

-- Approximate nearest-neighbour cosine index used by pgvector semantic retrieval.
CREATE INDEX IF NOT EXISTS "Opportunity_embedding_hnsw_idx"
ON "Opportunity" USING hnsw ("embedding" vector_cosine_ops);
