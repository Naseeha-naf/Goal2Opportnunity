-- AlterTable
ALTER TABLE "Opportunity" ALTER COLUMN "isVerified" SET DEFAULT false;
