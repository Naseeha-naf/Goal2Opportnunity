-- AlterTable
ALTER TABLE "Opportunity" ADD COLUMN     "retrievedAt" TIMESTAMP(3),
ADD COLUMN     "sourceId" TEXT NOT NULL DEFAULT 'manual',
ADD COLUMN     "verificationStatus" TEXT NOT NULL DEFAULT 'PENDING_REVIEW';

-- CreateTable
CREATE TABLE "Source" (
    "id" TEXT NOT NULL,
    "baseUrl" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Source_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OpportunityImport" (
    "id" TEXT NOT NULL,
    "sourceId" TEXT NOT NULL,
    "sourceUrl" TEXT NOT NULL,
    "opportunityId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING_REVIEW',
    "retrievedAt" TIMESTAMP(3) NOT NULL,
    "payloadJson" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "OpportunityImport_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "OpportunityImport_sourceId_retrievedAt_idx" ON "OpportunityImport"("sourceId", "retrievedAt");

-- CreateIndex
CREATE INDEX "OpportunityImport_status_createdAt_idx" ON "OpportunityImport"("status", "createdAt");
