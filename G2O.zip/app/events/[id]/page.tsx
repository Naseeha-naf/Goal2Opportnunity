'use client';

import React from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  Calendar,
  MapPin,
  Users,
  Trophy,
  CheckCircle2,
  Bookmark,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Award,
  Clock,
  ArrowRight
} from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';
import { trackDiscoveryEvent } from '@/lib/analytics/client';

export default function EventDetailPage() {
  const params = useParams();
  const { allOpportunities, toggleSaveOpportunity, savedOpportunityIds, parsedQuery } = useDiscovery();

  const oppId = params.id as string;
  const opp = allOpportunities.find((o) => o.id === oppId || o.slug === oppId);
  if (!opp) return <div className="py-20 text-center text-sm text-slate-500">Open this verified opportunity from discovery results to view its stored details.</div>;
  const isSaved = savedOpportunityIds.includes(opp.id);

  const formattedStartDate = new Date(opp.startDate).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const formattedDeadline = new Date(opp.registrationDeadline).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="space-y-8 py-4">
      {/* Top Banner Header */}
      <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-brand-950 to-indigo-950 text-white p-8 sm:p-10 overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-brand-500/20 rounded-full blur-3xl"></div>

        <div className="relative z-10 space-y-4 max-w-3xl">
          <div className="flex flex-wrap gap-2">
            <span className="bg-brand-500/30 text-brand-200 border border-brand-400/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {opp.opportunityType}
            </span>
            <span className="bg-white/10 text-white border border-white/20 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {opp.domain}
            </span>
            <span className="bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {opp.difficulty}
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
            {opp.title}
          </h1>

          <p className="text-slate-300 text-sm sm:text-base font-medium">
            Organized by <span className="text-white font-bold">{opp.organizer}</span>
          </p>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Event Overview & Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Key Facts Grid */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-brand-600" /> Start Date
              </span>
              <p className="font-bold text-slate-900">{formattedStartDate}</p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-brand-600" /> Location & Mode
              </span>
              <p className="font-bold text-slate-900">{opp.location} ({opp.mode})</p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-brand-600" /> Fee
              </span>
              <p className="font-bold text-emerald-700">{opp.fee === 0 ? 'Free' : `₹${opp.fee}`}</p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-500" /> Deadline
              </span>
              <p className="font-bold text-rose-600">{formattedDeadline}</p>
            </div>
          </div>

          {/* About Event */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
            <h2 className="text-xl font-bold text-slate-950">About This Opportunity</h2>
            <p className="text-slate-700 leading-relaxed text-sm sm:text-base">
              {opp.description}
            </p>

            <div className="pt-4 space-y-3">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Target Skills You Gain:
              </h3>
              <div className="flex flex-wrap gap-2">
                {opp.skills.map((skill, idx) => (
                  <span
                    key={idx}
                    className="bg-brand-50 text-brand-800 text-xs font-semibold px-3 py-1.5 rounded-lg border border-brand-100"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Eligibility & Team Info */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
            <h2 className="text-xl font-bold text-slate-950">Eligibility & Team Rules</h2>

            <div className="space-y-3 text-sm text-slate-700">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Student Eligibility:</strong> {opp.eligibilityText}
                </div>
              </div>

              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Team Size:</strong> {opp.teamAllowed ? `Teams allowed (${opp.teamMin}-${opp.teamMax} members per team)` : 'Individual participation only'}
                </div>
              </div>

              {opp.prize && (
                <div className="flex items-start gap-2">
                  <Trophy className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <strong>Prizes & Awards:</strong> {opp.prize}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side Sticky AI Recommendation Panel */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border-2 border-brand-500 p-6 shadow-xl sticky top-24 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="inline-flex items-center gap-1.5 bg-brand-50 text-brand-700 text-xs font-bold px-3 py-1 rounded-full border border-brand-100">
                <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>AI Recommendation</span>
              </div>

              <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-md">
                Verified listing
              </span>
            </div>

            <h3 className="font-extrabold text-slate-950 text-lg">
              ✨ Why Goal2Opportunity AI Recommended This
            </h3>

            {/* Match Checklist */}
            <ul className="space-y-2.5 text-xs text-slate-700">
              <li className="flex items-center gap-2 font-medium">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Stored domain: {opp.domain}</span>
              </li>
              <li className="flex items-center gap-2 font-medium">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Stored difficulty: {opp.difficulty}</span>
              </li>
              <li className="flex items-center gap-2 font-medium">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Stored fee: {opp.fee === 0 ? 'Free' : `₹${opp.fee}`}</span>
              </li>
              <li className="flex items-center gap-2 font-medium">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>{opp.eligibilityText}</span>
              </li>
              <li className="flex items-center gap-2 font-medium">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Starts {formattedStartDate}</span>
              </li>
            </ul>

            <Link
              href={`/discover/match/${opp.id}`}
              className="text-xs font-bold text-brand-600 hover:underline block text-center pt-2"
            >
              See Full Match Explanation →
            </Link>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <a
                href={opp.registrationUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackDiscoveryEvent('registration_cta_clicked', opp.id)}
                className="w-full inline-flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm"
              >
                <span>Register Now</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <button
                onClick={() => toggleSaveOpportunity(opp.id)}
                className={`w-full py-3 rounded-xl border font-semibold text-sm transition-colors flex items-center justify-center gap-2 ${
                  isSaved
                    ? 'bg-brand-50 border-brand-300 text-brand-700'
                    : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-brand-700' : ''}`} />
                <span>{isSaved ? 'Saved to Profile' : 'Save Event'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
