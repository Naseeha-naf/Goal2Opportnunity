'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Sparkles, CheckCircle2 } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function SignInPage() {
  const router = useRouter();
  const { signIn } = useDiscovery();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/auth/signin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Unable to sign in.');
      signIn(data.user.email, data.user.name || undefined);
      const next = typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('next') : null;
      router.push(next?.startsWith('/') ? next : '/');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally { setIsSubmitting(false); }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-6">
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-8 sm:p-12">
        {/* LEFT COLUMN: BRANDING & VALUE PROP */}
        <div className="space-y-6">
          <div className="flex items-center space-x-2">
            <div className="w-9 h-9 rounded-xl bg-brand-600 flex items-center justify-center text-white">
              <Sparkles className="w-5 h-5 fill-white/20" />
            </div>
            <span className="font-bold text-xl text-slate-950">Goal2Opportunity AI</span>
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 leading-tight">
              Discover the right opportunity for your goal.
            </h1>
            <p className="text-slate-600 text-sm leading-relaxed">
              Goal2Opportunity AI understands what you want to achieve and connects you to opportunities that can help you get there.
            </p>
          </div>

          {/* Feature Chips */}
          <div className="space-y-2.5 pt-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-brand-50/60 p-3 rounded-xl border border-brand-100">
              <CheckCircle2 className="w-4 h-4 text-brand-600 shrink-0" />
              <span>Goal Search — Describe what you want to achieve naturally</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-brand-50/60 p-3 rounded-xl border border-brand-100">
              <CheckCircle2 className="w-4 h-4 text-brand-600 shrink-0" />
              <span>Explainable Matches — Clear rationale for every match</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-brand-50/60 p-3 rounded-xl border border-brand-100">
              <CheckCircle2 className="w-4 h-4 text-brand-600 shrink-0" />
              <span>Hidden Discovery — Discover opportunities outside traditional keywords</span>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: SIGN-IN CARD */}
        <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl border border-slate-200 space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900">Student Sign In</h2>
            <p className="text-xs text-slate-500">Access your saved opportunities & personalized goals</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Student Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex.rivers@college.edu"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-brand-600 bg-white"
              />
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700">Password</label>
                <Link href="/reset-password" className="text-xs font-semibold text-brand-600 hover:underline">
                  Forgot password?
                </Link>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-brand-600 bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm"
            >
              {isSubmitting ? 'Signing in…' : 'Sign In'}
            </button>
            {error && <p role="alert" className="text-xs text-red-600 font-medium">{error}</p>}
          </form>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-3 text-[11px] font-semibold text-slate-400 uppercase">Or</span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          <p className="text-center text-xs text-slate-400">Google sign-in is not configured yet.</p>

          <div className="pt-2 text-center text-xs text-slate-500">
            Don't have an account?{' '}
            <Link href="/signup" className="font-bold text-brand-600 hover:underline">
              Create New Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
