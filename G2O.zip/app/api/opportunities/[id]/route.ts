import { NextResponse } from 'next/server';
import { getOpportunityByIdFromDb } from '@/lib/db/prisma';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const opp = await getOpportunityByIdFromDb(params.id);
    if (!opp) {
      return NextResponse.json({ error: 'Opportunity not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true, opportunity: opp });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch opportunity' }, { status: 500 });
  }
}
