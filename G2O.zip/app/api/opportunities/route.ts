import { NextResponse } from 'next/server';
import { getOpportunitiesFromDb, getOpportunityByIdFromDb } from '@/lib/db/prisma';

export async function GET(request: Request) {
  try {
    const opps = await getOpportunitiesFromDb();
    return NextResponse.json({ success: true, count: opps.length, opportunities: opps });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch opportunities' }, { status: 500 });
  }
}
