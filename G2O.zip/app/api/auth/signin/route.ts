import { NextResponse } from 'next/server';
import { z } from 'zod';
import { compare } from 'bcryptjs';
import { createSession } from '@/lib/auth/session';
import { prisma } from '@/lib/db/client';

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const input = schema.safeParse(body);
    if (!input.success) return NextResponse.json({ error: 'A valid email and password are required' }, { status: 400 });
    const user = await prisma.user.findUnique({ where: { email: input.data.email.toLowerCase() } });
    if (!user || !(await compare(input.data.password, user.password))) {
      return NextResponse.json({ error: 'Incorrect email or password.' }, { status: 401 });
    }
    const token = await createSession(user);
    const response = NextResponse.json({ success: true, user: { id: user.id, email: user.email, name: user.name } });
    response.cookies.set('g2o_session', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 24 * 7 });
    return response;
  } catch (error) {
    return NextResponse.json({ error: 'Authentication failed' }, { status: 500 });
  }
}
