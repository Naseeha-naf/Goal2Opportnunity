import { NextResponse } from 'next/server';
import { hash } from 'bcryptjs';
import { z } from 'zod';
import { createSession } from '@/lib/auth/session';
import { prisma } from '@/lib/db/client';

const schema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(8).max(128),
  profile: z.object({
    college: z.string().trim().max(160).optional(), degree: z.string().trim().max(80).optional(),
    department: z.string().trim().max(120).optional(), yearOfStudy: z.number().int().min(1).max(10).optional(),
    city: z.string().trim().max(100).optional(),
  }).optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const input = schema.safeParse(body);
    if (!input.success) return NextResponse.json({ error: 'Provide a name, valid email, and password of at least 8 characters.' }, { status: 400 });
    const email = input.data.email.toLowerCase();
    const existing = await prisma.user.findUnique({ where: { email }, select: { id: true } });
    if (existing) return NextResponse.json({ error: 'An account already exists for this email.' }, { status: 409 });

    const password = await hash(input.data.password, 12);
    const user = await prisma.user.create({
      data: {
        email, name: input.data.name, password,
        profile: { create: { interests: '[]', ...input.data.profile } },
      },
      select: { id: true, email: true, name: true },
    });
    const token = await createSession(user);
    const response = NextResponse.json({ success: true, user }, { status: 201 });
    response.cookies.set('g2o_session', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 24 * 7 });
    return response;
  } catch (error) {
    return NextResponse.json({ error: 'Signup failed' }, { status: 500 });
  }
}
