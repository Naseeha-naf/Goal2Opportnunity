import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db/client';

const eventSchema = z.object({
  name: z.enum([
    'discovery_search',
    'opportunity_opened',
    'registration_cta_clicked',
    'relaxation_approved',
  ]),
  opportunityId: z.string().min(1).max(200).optional(),
  metadata: z.record(z.union([z.string(), z.number(), z.boolean(), z.null()])).optional(),
});

/** Stores a deliberately small, allow-listed discovery funnel event. */
export async function POST(request: Request) {
  try {
    const body = eventSchema.parse(await request.json());
    await prisma.analyticsEvent.create({
      data: {
        name: body.name,
        opportunityId: body.opportunityId,
        metadataJson: JSON.stringify(body.metadata ?? {}),
      },
    });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Invalid analytics event' }, { status: 400 });
  }
}
