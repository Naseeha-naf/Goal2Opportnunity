import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { readSession } from '@/lib/auth/session';
import { prisma } from '@/lib/db/client';

const profileSchema = z.object({
  name: z.string().trim().min(2).max(100).optional(),
  college: z.string().trim().max(160).optional(),
  degree: z.string().trim().max(80).optional(),
  department: z.string().trim().max(120).optional(),
  yearOfStudy: z.number().int().min(1).max(10).optional(),
  graduationYear: z.number().int().min(2020).max(2100).optional(),
  city: z.string().trim().max(100).optional(),
  interests: z.array(z.string().trim().min(1).max(80)).max(20).optional(),
  preferredMode: z.enum(['ANY', 'ONLINE', 'OFFLINE', 'HYBRID']).optional(),
  preferredLocation: z.string().trim().max(100).optional(),
  typicalBudget: z.number().min(0).max(1000000).optional(),
  weekendAvailable: z.boolean().optional(),
  teamPreference: z.enum(['INDIVIDUAL', 'TEAM', 'EITHER']).optional(),
  completenessScore: z.number().int().min(0).max(100).optional(),
});

async function currentUser(request: NextRequest) {
  const session = await readSession(request.cookies.get('g2o_session')?.value);
  return session?.sub ?? null;
}

export async function GET(request: NextRequest) {
  const userId = await currentUser(request);
  if (!userId) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });
  const user = await prisma.user.findUnique({
    where: { id: userId }, select: { id: true, name: true, email: true, profile: true },
  });
  return user ? NextResponse.json({ user }) : NextResponse.json({ error: 'Account not found' }, { status: 404 });
}

export async function PATCH(request: NextRequest) {
  const userId = await currentUser(request);
  if (!userId) return NextResponse.json({ error: 'Sign in required' }, { status: 401 });
  const parsed = profileSchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: 'Some profile fields are invalid.' }, { status: 400 });
  const { interests, name, ...fields } = parsed.data;
  const profile = await prisma.profile.upsert({
    where: { userId }, create: { userId, interests: JSON.stringify(interests ?? []), ...fields },
    update: { ...(interests ? { interests: JSON.stringify(interests) } : {}), ...fields },
  });
  if (name) await prisma.user.update({ where: { id: userId }, data: { name } });
  return NextResponse.json({ profile, name: name ?? undefined });
}
