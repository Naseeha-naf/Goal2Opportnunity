import { NextResponse } from 'next/server';
import { timingSafeEqual } from 'crypto';
import { opportunityIngestionSchema } from '@/lib/ingestion/contract';
import { prisma } from '@/lib/db/client';
import { createHash } from 'crypto';

function hasValidSecret(request: Request) {
  const configured = process.env.G2O_INGESTION_SECRET;
  const supplied = request.headers.get('x-g2o-ingestion-secret');
  if (!configured || !supplied) return false;
  const a = Buffer.from(configured);
  const b = Buffer.from(supplied);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(request: Request) {
  if (!hasValidSecret(request)) return NextResponse.json({ error: 'Unauthorized ingestion request' }, { status: 401 });
  const payload = await request.json().catch(() => null);
  const parsed = opportunityIngestionSchema.safeParse(payload);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid opportunity payload', issues: parsed.error.flatten() }, { status: 422 });

  const item = parsed.data;
  const slug = `${item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 80)}-${createHash('sha256').update(item.sourceUrl).digest('hex').slice(0, 10)}`;
  try {
    const result = await prisma.$transaction(async (tx) => {
      await tx.source.upsert({ where: { id: item.sourceId }, create: { id: item.sourceId, baseUrl: new URL(item.sourceUrl).origin }, update: { baseUrl: new URL(item.sourceUrl).origin } });
      const opportunity = await tx.opportunity.upsert({
        where: { slug },
        create: {
          slug, title: item.title, description: item.description, shortDescription: item.description.slice(0, 280) || item.title,
          organizer: item.organizer, opportunityType: item.opportunityType, domain: item.domain, skills: JSON.stringify(item.skills), difficulty: item.difficulty,
          eligibilityText: item.eligibilityText, eligibleYears: JSON.stringify(item.eligibleYears), eligibleDegrees: JSON.stringify(item.eligibleDegrees),
          location: item.location || 'Not supplied by source', city: '', state: '', mode: item.mode === 'UNKNOWN' ? 'ONLINE' : item.mode,
          fee: item.fee ?? 0, startDate: item.startDate, endDate: item.endDate, registrationDeadline: item.registrationDeadline || item.startDate,
          registrationUrl: item.registrationUrl || item.sourceUrl, sourceUrl: item.sourceUrl, sourceId: item.sourceId, retrievedAt: item.retrievedAt,
          verificationStatus: 'PENDING_REVIEW', isVerified: false,
        },
        update: {
          title: item.title, description: item.description, shortDescription: item.description.slice(0, 280) || item.title,
          organizer: item.organizer, opportunityType: item.opportunityType, domain: item.domain, skills: JSON.stringify(item.skills), difficulty: item.difficulty,
          eligibilityText: item.eligibilityText, eligibleYears: JSON.stringify(item.eligibleYears), eligibleDegrees: JSON.stringify(item.eligibleDegrees),
          location: item.location || 'Not supplied by source', mode: item.mode === 'UNKNOWN' ? 'ONLINE' : item.mode, fee: item.fee ?? 0,
          startDate: item.startDate, endDate: item.endDate, registrationDeadline: item.registrationDeadline || item.startDate,
          registrationUrl: item.registrationUrl || item.sourceUrl, retrievedAt: item.retrievedAt, verificationStatus: 'PENDING_REVIEW', isVerified: false,
        },
      });
      const importRecord = await tx.opportunityImport.create({ data: { sourceId: item.sourceId, sourceUrl: item.sourceUrl, opportunityId: opportunity.id, status: 'PENDING_REVIEW', retrievedAt: item.retrievedAt, payloadJson: JSON.stringify(item) } });
      return { opportunity, importRecord };
    });
    return NextResponse.json({ accepted: true, status: 'PENDING_REVIEW', opportunityId: result.opportunity.id, importId: result.importRecord.id }, { status: 202 });
  } catch {
    return NextResponse.json({ error: 'Database persistence failed' }, { status: 503 });
  }
}
