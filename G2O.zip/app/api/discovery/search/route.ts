import { NextResponse } from 'next/server';
import { parseUserQueryWithSource } from '@/lib/ai/queryParser';
import { executeHybridSearch } from '@/lib/search/hybridSearch';
import { findHiddenOpportunities } from '@/lib/search/hiddenDiscovery';
import { applyApprovedRelaxation, resolveConstraintConflict } from '@/lib/search/constraintResolver';
import { getLexicalCandidatesFromDb, getOpportunitiesFromDb } from '@/lib/db/prisma';
import { findSemanticCandidates } from '@/lib/search/semanticSearch';

export async function POST(request: Request) {
  try {
    const { query, profile, approvedRelaxation } = await request.json();
    if (!query) {
      return NextResponse.json({ error: 'Query string is required' }, { status: 400 });
    }

    const parsedResponse = await parseUserQueryWithSource(query, profile);
    const parsed = approvedRelaxation ? applyApprovedRelaxation(parsedResponse.parsed, approvedRelaxation) : parsedResponse.parsed;
    const provider = parsedResponse.provider;
    const [baseOpps, semanticCandidates] = await Promise.all([
      getLexicalCandidatesFromDb(parsed),
      findSemanticCandidates(parsed),
    ]);
    const semanticScores = new Map(semanticCandidates.map((candidate) => [candidate.opportunity.id, candidate.similarity]));
    const merged = new Map(baseOpps.map((opp) => [opp.id, opp]));
    for (const candidate of semanticCandidates) merged.set(candidate.opportunity.id, candidate.opportunity);
    const allOpps = Array.from(merged.values());
    const searchRes = executeHybridSearch(allOpps, parsed, semanticScores);

    if (searchRes.exactMatches.length > 0) {
      const hidden = findHiddenOpportunities(searchRes.exactMatches, parsed);
      return NextResponse.json({
        success: true,
        query: parsed,
        totalMatches: searchRes.exactMatches.length,
        results: searchRes.exactMatches,
        hiddenOpportunity: hidden,
        conflict: null,
        parserProvider: provider,
        appliedRelaxation: approvedRelaxation || null,
      });
    } else {
      // Recovery needs a broader verified pool so it can measure which single
      // constraint change actually restores results.
      const recoveryPool = await getOpportunitiesFromDb();
      const conflict = resolveConstraintConflict(recoveryPool, parsed);
      return NextResponse.json({
        success: true,
        query: parsed,
        totalMatches: 0,
        results: [],
        hiddenOpportunity: null,
        conflict,
        parserProvider: provider,
        appliedRelaxation: null,
      });
    }
  } catch (error) {
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
