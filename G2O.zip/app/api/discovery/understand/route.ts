import { NextResponse } from 'next/server';
import { parseUserQueryWithSource } from '@/lib/ai/queryParser';

export async function POST(request: Request) {
  try {
    const { query, profile } = await request.json();
    if (!query) {
      return NextResponse.json({ error: 'Query string is required' }, { status: 400 });
    }

    const { parsed, provider } = await parseUserQueryWithSource(query, profile);
    return NextResponse.json({ success: true, parsed, provider });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to understand query' }, { status: 500 });
  }
}
