import type { Metadata } from 'next';
import './globals.css';
import { DiscoveryProvider } from '@/lib/context/DiscoveryContext';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';

export const metadata: Metadata = {
  title: 'Goal2Opportunity AI | AI Smart Search & Discovery Assistant',
  description: 'Don’t search for opportunities. Tell us what you want to achieve.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-slate-50 text-slate-900 antialiased">
        <DiscoveryProvider>
          <Navbar />
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {children}
          </main>
          <Footer />
        </DiscoveryProvider>
      </body>
    </html>
  );
}
