'use client';

import React from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { Sparkles, Check, AlertCircle, ArrowLeft, ArrowRight, ShieldCheck, Award } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';
import { generateMatchExplanation } from '@/lib/ai/explanation';

export default function MatchExplanationPage() {
  const params = useParams();
  const router = useRouter();
  const { searchResults, allOpportunities, parsedQuery } = useDiscovery();

  const oppId = params.id as string;
  const matchResult = searchResults.find((r) => r.opportunity.id === oppId || r.opportunity.slug === oppId) || null;

  if (!matchResult) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-600">Opportunity match details not found.</p>
        <Link href="/discover/results" className="text-brand-600 font-semibold hover:underline mt-2 inline-block">
          Return to Results
        </Link>
      </div>
    );
  }

  const { opportunity, totalScore, breakdown } = matchResult;
  const currentQuery = parsedQuery;
  if (!currentQuery) return <div className="text-center py-20 text-sm text-slate-500">Run a search first to view a grounded match explanation.</div>;

  const explanation = generateMatchExplanation(matchResult, currentQuery);

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Page Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 bg-brand-50 border border-brand-200 text-brand-700 text-xs font-bold px-3.5 py-1.5 rounded-full">
          <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>Explainable Match System</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-950 tracking-tight">
          Why This Opportunity Fits Your Goal
        </h1>
        <p className="text-slate-600 text-base max-w-lg mx-auto">
          Transparent match breakdown showing how {opportunity.title} aligns with your goal.
        </p>
      </div>

      {/* Main Score & Title Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
              {opportunity.opportunityType} • {opportunity.domain}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 mt-1">
              {opportunity.title}
            </h2>
            <p className="text-slate-500 text-xs mt-1">Organized by {opportunity.organizer}</p>
          </div>

          <div className="bg-gradient-to-br from-brand-600 to-indigo-600 text-white rounded-2xl p-4 text-center shadow-lg shadow-brand-600/20 shrink-0 min-w-[140px]">
            <span className="text-3xl font-black">{totalScore}%</span>
            <p className="text-[11px] text-brand-100 font-semibold tracking-wider uppercase mt-0.5">
              Goal Match Score
            </p>
          </div>
        </div>

        {/* Score Breakdown Progress Bars */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            SCORE BREAKDOWN BY FACTOR
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-semibold text-slate-700">
            {/* Goal Relevance */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span>Goal Relevance</span>
                <span className="font-bold text-brand-700">{breakdown.goalRelevance}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-brand-600 rounded-full"
                  style={{ width: `${breakdown.goalRelevance}%` }}
                ></div>
              </div>
            </div>

            {/* Skill Level Match */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span>Skill Level Match</span>
                <span className="font-bold text-brand-700">{breakdown.skillMatch}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-600 rounded-full"
                  style={{ width: `${breakdown.skillMatch}%` }}
                ></div>
              </div>
            </div>

            {/* Budget Match */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span>Budget Match</span>
                <span className="font-bold text-emerald-700">{breakdown.budgetMatch}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${breakdown.budgetMatch}%` }}
                ></div>
              </div>
            </div>

            {/* Eligibility Match */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span>Eligibility Match</span>
                <span className="font-bold text-emerald-700">{breakdown.eligibilityMatch}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${breakdown.eligibilityMatch}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* WHY IT MATCHES Grounded Summary */}
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 space-y-2">
          <h4 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 stroke-[3]" /> WHY IT MATCHES YOUR GOAL
          </h4>
          <p className="text-sm text-emerald-900 leading-relaxed">
            {explanation.summaryText}
          </p>
        </div>

        {/* HOW THIS HELPS Section */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-2">
          <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Award className="w-4 h-4 text-brand-600" /> HOW THIS HELPS YOU ACHIEVE YOUR GOAL
          </h4>
          <p className="text-sm text-slate-700 leading-relaxed">
            {explanation.howThisHelps}
          </p>
        </div>

        {/* Requirements Checklist */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            REQUIREMENTS CHECKLIST
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
            {explanation.checklist.map((item, idx) => (
              <div
                key={idx}
                className="bg-white border border-slate-200 p-3 rounded-xl flex items-center justify-between"
              >
                <span className="font-semibold text-slate-800">{item.label}</span>
                <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  ✓ {item.details}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Preference Mismatch / Soft Warning (if any) */}
        {explanation.preferenceNotice && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-900">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Soft Preference Mismatch:</span> {explanation.preferenceNotice}
            </div>
          </div>
        )}

        {/* Grounding Info Box */}
        <div className="bg-purple-50/60 border border-purple-200 rounded-xl p-4 text-xs text-purple-900 flex items-start gap-3">
          <ShieldCheck className="w-4 h-4 text-brand-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Goal2Opportunity AI Transparency Guarantee:</strong> Goal2Opportunity AI separates mandatory requirements from preferences so important constraints aren’t silently ignored.
          </p>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <button
          onClick={() => router.push('/discover/results')}
          className="w-full sm:w-auto px-6 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-sm transition-colors flex items-center justify-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Results</span>
        </button>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Link
            href={`/events/${opportunity.id}`}
            className="w-full sm:w-auto px-6 py-3 rounded-xl border border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white font-bold text-sm transition-colors text-center"
          >
            View Full Event Page
          </Link>
          <a
            href={opportunity.registrationUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm"
          >
            <span>Register Now</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
