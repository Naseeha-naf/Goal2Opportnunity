'use client';

import React from 'react';
import Link from 'next/link';
import { ConstraintConflictCard } from '@/components/discovery/ConstraintConflictCard';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function NoMatchPage() {
  const { constraintConflict, parsedQuery } = useDiscovery();

  if (!constraintConflict) {
    return <div className="py-16 text-center text-sm text-slate-500">Run a search first to view a measured zero-result recovery option.</div>;
  }

  return (
    <div className="py-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-black text-slate-950">
          Smart Constraint Resolution
        </h1>
        <p className="text-slate-500 text-sm">
          No results does not have to be a dead end. Goal2Opportunity AI identifies the smallest useful change to unlock matching opportunities.
        </p>
      </div>

      <ConstraintConflictCard conflict={constraintConflict} />
    </div>
  );
}
