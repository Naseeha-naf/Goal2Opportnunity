'use client';

import React from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { Gem, ArrowRight, ArrowLeft, CheckCircle2, Sparkles, Target, Zap, ShieldCheck } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function HiddenOpportunityDiscoveryPage() {
  const params = useParams();
  const router = useRouter();
  const { allOpportunities, parsedQuery, hiddenOpportunity } = useDiscovery();

  const oppId = params.id as string;
  const opp = allOpportunities.find((o) => o.id === oppId || o.slug === oppId) || hiddenOpportunity?.opportunity;

  if (!opp) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-600">Opportunity not found.</p>
        <Link href="/discover/results" className="text-brand-600 font-semibold hover:underline mt-2 inline-block">
          Return to Results
        </Link>
      </div>
    );
  }

  const goalText = parsedQuery?.goal || 'AI Internship Preparation';

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Header Badge & Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 bg-purple-100 border border-purple-300 text-purple-800 text-xs font-bold px-4 py-1.5 rounded-full shadow-sm">
          <Gem className="w-4 h-4 text-purple-600 fill-purple-600" />
          <span>💎 Hidden Opportunity Discovery</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 tracking-tight">
          Opportunity You May Have Missed
        </h1>
        <p className="text-slate-600 text-base max-w-xl mx-auto">
          Goal2Opportunity AI found an opportunity outside your original search that still supports the same goal.
        </p>
      </div>

      {/* Visual Reasoning Box */}
      <div className="bg-gradient-to-br from-slate-900 via-purple-950 to-indigo-950 text-white rounded-3xl p-8 shadow-2xl border border-purple-500/20 space-y-8">
        {/* Step-by-Step Goal Mapping */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center text-center">
          <div className="bg-white/10 p-5 rounded-2xl border border-white/10 space-y-2">
            <span className="text-[10px] font-bold tracking-widest text-purple-300 uppercase">
              YOU WERE LOOKING FOR
            </span>
            <h4 className="font-bold text-white text-base">{goalText}</h4>
          </div>

          <div className="flex justify-center text-purple-400">
            <ArrowRight className="w-8 h-8 rotate-90 md:rotate-0" />
          </div>

          <div className="bg-gradient-to-r from-amber-500/20 to-brand-500/20 p-5 rounded-2xl border border-amber-400/30 space-y-2">
            <span className="text-[10px] font-bold tracking-widest text-amber-300 uppercase flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> AI DISCOVERED
            </span>
            <h4 className="font-bold text-white text-base">{opp.title}</h4>
          </div>
        </div>

        {/* Core Rationale Explanation Box */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/15 space-y-3">
          <h3 className="text-sm font-bold tracking-wider text-purple-200 uppercase flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" /> WHY GOAL2OPPORTUNITY AI FOUND THIS
          </h3>
          <p className="text-purple-100 text-base sm:text-lg leading-relaxed italic">
            “This is a {opp.opportunityType.toLowerCase()} in the stored {opp.domain} domain. It is shown because it meets the validated search constraints while being a category you did not explicitly request.”
          </p>
        </div>

        {/* Visual Chain: GOAL -> NEED -> OPPORTUNITY */}
        <div className="bg-slate-950/60 rounded-2xl p-6 border border-slate-800 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            INFERRED VALUE CHAIN
          </h4>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm font-bold">
            <div className="bg-purple-900/60 text-purple-200 px-4 py-2 rounded-xl border border-purple-700/50 w-full sm:w-auto text-center">
              GOAL: {goalText}
            </div>
            <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 hidden sm:block" />
            <div className="bg-indigo-900/60 text-indigo-200 px-4 py-2 rounded-xl border border-indigo-700/50 w-full sm:w-auto text-center">
              MATCHED DOMAIN: {opp.domain}
            </div>
            <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 hidden sm:block" />
            <div className="bg-emerald-900/60 text-emerald-200 px-4 py-2 rounded-xl border border-emerald-700/50 w-full sm:w-auto text-center">
              OPPORTUNITY: {opp.title}
            </div>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-purple-300">
            KEY GOAL BENEFITS
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              `Stored domain: ${opp.domain}`,
              `Stored type: ${opp.opportunityType}`,
              `Stored difficulty: ${opp.difficulty}`,
              `Stored fee: ${opp.fee === 0 ? 'Free' : `₹${opp.fee}`}`,
              `Eligibility: ${opp.eligibilityText}`,
              `Registration deadline: ${new Date(opp.registrationDeadline).toLocaleDateString()}`,
            ].map((b, i) => (
              <div key={i} className="bg-white/5 px-3.5 py-2.5 rounded-xl border border-white/10 text-xs font-medium text-purple-100 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Guarantee Label */}
        <p className="text-center text-xs text-purple-300/70 font-medium italic pt-2">
          ✨ Discovered through goal relevance, not keyword similarity.
        </p>
      </div>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <button
          onClick={() => router.push('/discover/results')}
          className="w-full sm:w-auto px-6 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-sm transition-colors flex items-center justify-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Results</span>
        </button>

        <Link
          href={`/events/${opp.id}`}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold px-8 py-3.5 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm"
        >
          <span>View Full Opportunity Details</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
