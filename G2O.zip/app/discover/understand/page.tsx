'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, Edit3, ArrowRight, CheckCircle2, Info, Lightbulb, Target } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function GoalUnderstandingPage() {
  const router = useRouter();
  const { rawQuery, parsedQuery, executeSearch } = useDiscovery();

  if (!parsedQuery) {
    return (
      <div className="text-center py-20">
        <Sparkles className="w-10 h-10 text-brand-600 animate-spin mx-auto mb-4" />
        <p className="text-slate-600 font-medium">Goal2Opportunity AI is understanding your goal...</p>
      </div>
    );
  }

  const handleContinue = () => {
    router.push('/discover/results');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 bg-brand-50 border border-brand-200 text-brand-700 text-xs font-bold px-3.5 py-1.5 rounded-full">
          <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>Transparent AI Interpretation</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 tracking-tight">
          ✨ Goal2Opportunity AI Understood Your Goal
        </h1>
        <p className="text-slate-600 text-base max-w-xl mx-auto">
          Here’s what we understood from your request. You can edit anything before we search.
        </p>
      </div>

      {/* Original Input Display Box */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
          <span>YOUR ORIGINAL REQUEST</span>
          <button
            onClick={() => router.push('/')}
            className="text-brand-600 hover:underline flex items-center gap-1"
          >
            <Edit3 className="w-3.5 h-3.5" /> Edit Query
          </button>
        </div>
        <p className="text-slate-900 font-medium text-lg italic bg-slate-50 p-4 rounded-xl border border-slate-100">
          “{rawQuery}”
        </p>
      </div>

      {/* Structured AI Extraction Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        {/* Core Goal & Intent */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-slate-100">
          <div className="space-y-2 bg-brand-50/50 p-4 rounded-xl border border-brand-100">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-700 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-brand-600" /> YOUR GOAL
            </span>
            <p className="text-lg font-bold text-slate-900 leading-snug">
              {parsedQuery.goal}
            </p>
          </div>

          <div className="space-y-2 bg-indigo-50/50 p-4 rounded-xl border border-indigo-100">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-indigo-600" /> DETECTED INTENT
            </span>
            <p className="text-lg font-bold text-slate-900 leading-snug">
              {parsedQuery.intent}
            </p>
          </div>
        </div>

        {/* Extracted Hard Requirements */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            EXTRACTED REQUIREMENTS & CONSTRAINTS
          </h3>
          <div className="flex flex-wrap gap-2">
            {parsedQuery.hardConstraints.map((req, idx) => (
              <span
                key={idx}
                className="bg-emerald-50 text-emerald-800 text-xs font-semibold px-3.5 py-2 rounded-xl border border-emerald-200 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                {req}
              </span>
            ))}
            {parsedQuery.domains.map((d, idx) => (
              <span
                key={'d-' + idx}
                className="bg-purple-50 text-purple-800 text-xs font-semibold px-3.5 py-2 rounded-xl border border-purple-200"
              >
                Domain: {d}
              </span>
            ))}
          </div>
        </div>

        {/* Expanded Potential Opportunity Types */}
        <div className="space-y-3 pt-2">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            EXPANDED OPPORTUNITY TYPES TO SEARCH
          </h3>
          <div className="flex flex-wrap gap-2">
            {parsedQuery.opportunityTypes.map((type, idx) => (
              <span
                key={idx}
                className="bg-slate-100 text-slate-800 text-xs font-semibold px-3.5 py-2 rounded-xl border border-slate-200"
              >
                {type}
              </span>
            ))}
          </div>
        </div>

        {/* Important AI Helper Notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-900">
          <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Goal2Opportunity AI Rule:</strong> The system may search beyond the categories you explicitly mentioned when another opportunity supports the same underlying goal (e.g. recommending a hackathon for internship preparation).
          </p>
        </div>
      </div>

      {/* Action CTA Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <button
          onClick={() => router.push('/')}
          className="w-full sm:w-auto px-6 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-sm transition-colors text-center"
        >
          Edit Goal
        </button>

        <button
          onClick={handleContinue}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold px-8 py-3.5 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm"
        >
          <span>Continue Discovery & View Results</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
