'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Sparkles, Filter, SlidersHorizontal, ArrowUpDown, ChevronRight, Check } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';
import { OpportunityCard } from '@/components/opportunities/OpportunityCard';
import { HiddenOpportunityCard } from '@/components/discovery/HiddenOpportunityCard';
import { ConstraintConflictCard } from '@/components/discovery/ConstraintConflictCard';

export default function ResultsPage() {
  const router = useRouter();
  const { searchResults, hiddenOpportunity, parsedQuery, constraintConflict, rawQuery } = useDiscovery();
  const [selectedFilterType, setSelectedFilterType] = useState<string>('ALL');

  if (constraintConflict && searchResults.length === 0) {
    return (
      <div className="py-6">
        <ConstraintConflictCard conflict={constraintConflict} />
      </div>
    );
  }

  const filteredResults = searchResults.filter((r) => {
    if (selectedFilterType === 'ALL') return true;
    return r.opportunity.opportunityType === selectedFilterType;
  });

  return (
    <div className="space-y-8 py-4">
      {/* Top Title & Goal Summary Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-brand-50 text-brand-700 text-xs font-bold px-3 py-1 rounded-full border border-brand-100 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>Verified Matches</span>
            </div>
            <h1 className="text-3xl font-black text-slate-950 tracking-tight">
              Recommended Opportunities For You
            </h1>
            <p className="text-slate-500 text-sm mt-1">
              Selected based on your goal, eligibility and requirements.
            </p>
          </div>

          <button
            onClick={() => router.push('/discover/understand')}
            className="text-xs font-semibold text-brand-600 hover:bg-brand-50 px-3.5 py-2 rounded-xl border border-brand-200 transition-colors self-start md:self-auto"
          >
            Edit Goal Requirements
          </button>
        </div>

        {/* Query Summary & Constraint Chips Bar */}
        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="font-bold text-slate-700">Searching for:</span>
          <span className="bg-slate-100 text-slate-800 font-semibold px-3 py-1 rounded-lg">
            {parsedQuery?.goal || rawQuery}
          </span>
          {parsedQuery?.hardConstraints.map((chip, idx) => (
            <span key={idx} className="bg-brand-50 text-brand-700 font-medium px-2.5 py-1 rounded-lg border border-brand-100">
              ✓ {chip}
            </span>
          ))}
        </div>
      </div>

      {/* Controls & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-xs font-medium">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-500 font-bold uppercase tracking-wider">Type Filter:</span>
          {['ALL', 'Hackathon', 'Competition', 'Workshop', 'Open Source', 'Research', 'Design'].map((t) => (
            <button
              key={t}
              onClick={() => setSelectedFilterType(t)}
              className={`px-3 py-1.5 rounded-lg border transition-colors ${
                selectedFilterType === t
                  ? 'bg-brand-600 text-white border-brand-600 font-bold'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-slate-600">
          <SlidersHorizontal className="w-4 h-4 text-slate-400" />
          <span>Sort by: <strong>Best Goal Match</strong></span>
        </div>
      </div>

      {/* SPECIAL HIDDEN OPPORTUNITY CARD */}
      {hiddenOpportunity && (
        <HiddenOpportunityCard hiddenMatch={hiddenOpportunity} />
      )}

      {/* OPPORTUNITY CARDS LIST */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900">
            {filteredResults.length} Feasible Opportunities Found
          </h3>
          <span className="text-xs text-slate-500">0 Hard Constraint Violations</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredResults.map((result) => (
            <OpportunityCard key={result.opportunity.id} result={result} />
          ))}
        </div>
      </div>
    </div>
  );
}
