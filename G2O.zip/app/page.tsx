'use client';

import React from 'react';
import Link from 'next/link';
import { Sparkles, TrendingUp, Calendar, ArrowRight, Zap, Target } from 'lucide-react';
import { GoalSearchBox } from '@/components/discovery/GoalSearchBox';
import { OpportunityCard } from '@/components/opportunities/OpportunityCard';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function HomePage() {
  const { searchResults, allOpportunities } = useDiscovery();

  const featured = searchResults.length > 0 ? searchResults.slice(0, 3) : [];
  const trendingOpps = allOpportunities.slice(3, 6);

  return (
    <div className="space-y-16 py-6">
      {/* HERO SECTION */}
      <section className="text-center space-y-6 max-w-4xl mx-auto pt-6 pb-4">
        <div className="inline-flex items-center gap-2 bg-brand-50 border border-brand-200 text-brand-700 text-xs font-bold px-3.5 py-1.5 rounded-full shadow-sm">
          <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span>✨ Goal2Opportunity AI Discovery</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-950 tracking-tight leading-tight">
          Discover Opportunities <br className="hidden sm:inline" />
          Built Around <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-indigo-600">Your Goal</span>
        </h1>

        <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto font-normal">
          Tell us what you want to achieve and discover opportunities you may never think to search for.
        </p>

        {/* Natural Language Goal Input Component */}
        <div className="pt-4">
          <GoalSearchBox />
        </div>
      </section>

      {/* THREE STEP VALUE PROPOSITION */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 py-6 border-y border-slate-200">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-xl bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-base">
            1
          </div>
          <h3 className="font-bold text-slate-900 text-base">Describe Your Goal</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Enter what you want to achieve naturally (e.g. practical AI experience, building a portfolio, public speaking).
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-base">
            2
          </div>
          <h3 className="font-bold text-slate-900 text-base">AI Need Interpretation</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Goal2Opportunity AI expands your goal into feasible opportunity types and extracts strict constraints.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-base">
            3
          </div>
          <h3 className="font-bold text-slate-900 text-base">Discover & Achieve</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Get ranked real-world opportunities, grounded match explanations, and hidden event discoveries.
          </p>
        </div>
      </section>

      {/* FEATURED / SEARCH RESULTS SECTION */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <Zap className="w-6 h-6 text-brand-600" /> Featured Goal Matches
            </h2>
            <p className="text-sm text-slate-500">
              Matched based on goal intent, beginner eligibility, and budget constraints.
            </p>
          </div>

          <Link
            href="/discover/results"
            className="text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            <span>View All ({allOpportunities.length})</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.map((item) => (
            <OpportunityCard key={item.opportunity.id} result={item} />
          ))}
        </div>
      </section>

      {/* TRENDING OPPORTUNITIES SECTION */}
      <section className="space-y-6 bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-indigo-600" /> Trending Student Opportunities
            </h2>
            <p className="text-sm text-slate-500">Popular hackathons and project challenges in Coimbatore, Chennai & Bengaluru.</p>
          </div>

          <Link href="/discover/results" className="text-xs font-semibold text-slate-600 hover:text-slate-900">
            Explore More →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trendingOpps.map((opp) => (
            <div key={opp.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-brand-300 transition-all space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                <span>{opp.opportunityType}</span>
                <span className="text-emerald-600 font-bold">{opp.fee === 0 ? 'Free' : `₹${opp.fee}`}</span>
              </div>
              <h4 className="font-bold text-slate-900 text-base">{opp.title}</h4>
              <p className="text-xs text-slate-600 line-clamp-2">{opp.shortDescription}</p>
              <div className="pt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500">{opp.city}</span>
                <Link href={`/events/${opp.id}`} className="text-brand-600 font-semibold hover:underline">
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
