'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { User, Sparkles, Check, Bookmark, ArrowRight, Save, Award } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';
import { OpportunityCard } from '@/components/opportunities/OpportunityCard';

export default function ProfilePage() {
  const router = useRouter();
  const { profile, updateProfile, savedOpportunityIds, allOpportunities } = useDiscovery();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ ...profile });

  const savedItems = allOpportunities
    .filter((o) => savedOpportunityIds.includes(o.id))
    .map((opp) => ({
      opportunity: opp,
      totalScore: 94,
      breakdown: {
        goalRelevance: 95,
        intentRelevance: 92,
        skillMatch: 90,
        budgetMatch: 100,
        eligibilityMatch: 100,
        availabilityMatch: 95,
        preferenceMatch: 90,
        freshnessScore: 100,
      },
      reasons: ['Saved opportunity from search', 'Fits your profile preferences'],
      mismatches: [],
    }));

  const [saveError, setSaveError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError(''); setIsSaving(true);
    try {
      const response = await fetch('/api/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(formData) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not save your profile.');
      updateProfile(formData); setIsEditing(false);
    } catch (err) { setSaveError(err instanceof Error ? err.message : 'Could not save your profile.'); }
    finally { setIsSaving(false); }
  };

  const INTEREST_LIST = [
    'AI / ML',
    'Web Development',
    'Cybersecurity',
    'IoT',
    'Robotics',
    'Design',
    'Entrepreneurship',
    'Open Source',
    'Research',
    'Public Speaking',
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-4">
      {/* Header Profile Summary */}
      <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-2xl bg-brand-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-brand-600/20">
            {profile.name.charAt(0)}
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-950">{profile.name}</h1>
            <p className="text-xs text-slate-500 font-medium">
              {profile.degree} in {profile.department} • {profile.college}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">{profile.city}, India</p>
          </div>
        </div>

        {/* Profile Completeness Box */}
        <div className="bg-brand-50 border border-brand-200 rounded-2xl p-4 min-w-[200px] text-center space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-700">
            Profile Completeness
          </span>
          <div className="text-2xl font-black text-brand-900">{profile.completenessScore}%</div>
          <div className="w-full h-2 bg-brand-200 rounded-full overflow-hidden">
            <div className="h-full bg-brand-600 rounded-full" style={{ width: `${profile.completenessScore}%` }}></div>
          </div>
        </div>
      </div>

      {/* Main Profile Settings Form */}
      <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <h2 className="text-xl font-bold text-slate-950">Student Profile & Preferences</h2>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-xs font-semibold text-brand-600 hover:underline"
          >
            {isEditing ? 'Cancel Edit' : 'Edit Profile'}
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Full Name</label>
              <input
                disabled={!isEditing}
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Email</label>
              <input
                disabled
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">City</label>
              <input
                disabled={!isEditing}
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">College</label>
              <input
                disabled={!isEditing}
                type="text"
                value={formData.college}
                onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Degree</label>
              <input
                disabled={!isEditing}
                type="text"
                value={formData.degree}
                onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Year of Study</label>
              <input
                disabled={!isEditing}
                type="number"
                value={formData.yearOfStudy}
                onChange={(e) => setFormData({ ...formData, yearOfStudy: parseInt(e.target.value, 10) })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 font-medium disabled:bg-slate-50"
              />
            </div>
          </div>

          {/* Interests Chips Selection */}
          <div className="space-y-3 pt-2">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Selected Skill Interests
            </label>
            <div className="flex flex-wrap gap-2">
              {INTEREST_LIST.map((interest) => {
                const isSelected = formData.interests.includes(interest);
                return (
                  <button
                    type="button"
                    key={interest}
                    disabled={!isEditing}
                    onClick={() => {
                      if (!isEditing) return;
                      const updated = isSelected
                        ? formData.interests.filter((i) => i !== interest)
                        : [...formData.interests, interest];
                      setFormData({ ...formData, interests: updated });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                      isSelected
                        ? 'bg-brand-600 text-white border-brand-600'
                        : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}
                  >
                    {interest}
                  </button>
                );
              })}
            </div>
          </div>

          {isEditing && (
            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className="bg-brand-600 hover:bg-brand-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition-all shadow-md flex items-center gap-2"
              >
                <Save className="w-4 h-4" /> {isSaving ? 'Saving…' : 'Save Profile'}
              </button>
            </div>
          )}
          {saveError && <p role="alert" className="text-xs text-red-600 font-medium text-right">{saveError}</p>}
        </form>
      </div>

      {/* SAVED OPPORTUNITIES SECTION */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-extrabold text-slate-950 flex items-center gap-2">
            <Bookmark className="w-6 h-6 text-brand-600" /> Saved Opportunities ({savedItems.length})
          </h2>
          <Link href="/" className="text-xs font-semibold text-brand-600 hover:underline">
            Back to AI Discovery →
          </Link>
        </div>

        {savedItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {savedItems.map((item) => (
              <OpportunityCard key={item.opportunity.id} result={item} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 text-xs">
            No saved opportunities yet. Click the bookmark icon on any opportunity card to save it.
          </div>
        )}
      </div>
    </div>
  );
}
