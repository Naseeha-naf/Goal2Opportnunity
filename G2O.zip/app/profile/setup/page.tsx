'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, ArrowRight, Check } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export default function ProfileSetupPage() {
  const router = useRouter();
  const { profile, updateProfile } = useDiscovery();
  const [formData, setFormData] = useState({ ...profile });

  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setIsSaving(true);
    const payload = { ...formData, completenessScore: 100 };
    try {
      const response = await fetch('/api/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not save your profile.');
      updateProfile(payload);
      router.push('/'); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not save your profile.'); }
    finally { setIsSaving(false); }
  };

  const INTEREST_LIST = [
    'AI / ML',
    'Web Development',
    'Cybersecurity',
    'IoT',
    'Robotics',
    'Design',
    'Entrepreneurship',
    'Open Source',
    'Research',
    'Public Speaking',
  ];

  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-10 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center text-white mx-auto">
            <Sparkles className="w-5 h-5 fill-white/20" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-950">
            Student Profile Setup
          </h1>
          <p className="text-xs text-slate-500">
            Configure your background and preferences to improve eligibility checks & match relevance
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Preferred Event Mode</label>
              <select
                value={formData.preferredMode}
                onChange={(e) => setFormData({ ...formData, preferredMode: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white"
              >
                <option value="ANY">Any Mode (Online or Offline)</option>
                <option value="ONLINE">Online / Virtual Only</option>
                <option value="OFFLINE">Offline / In-person Only</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Typical Budget Limit (₹)</label>
              <input
                type="number"
                value={formData.typicalBudget}
                onChange={(e) => setFormData({ ...formData, typicalBudget: parseInt(e.target.value, 10) })}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Select Your Interests (Click to toggle)
            </label>
            <div className="flex flex-wrap gap-2">
              {INTEREST_LIST.map((interest) => {
                const isSelected = formData.interests.includes(interest);
                return (
                  <button
                    type="button"
                    key={interest}
                    onClick={() => {
                      const updated = isSelected
                        ? formData.interests.filter((i) => i !== interest)
                        : [...formData.interests, interest];
                      setFormData({ ...formData, interests: updated });
                    }}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                      isSelected
                        ? 'bg-brand-600 text-white border-brand-600 shadow-sm'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {interest}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 flex items-center justify-between">
            <button
              type="button"
              onClick={() => router.push('/')}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800"
            >
              Skip for now
            </button>

            <button
              type="submit"
              className="bg-brand-600 hover:bg-brand-700 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-md shadow-brand-600/30 text-sm flex items-center gap-2"
            >
              <span>{isSaving ? 'Saving…' : 'Save & Complete Setup'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          {error && <p role="alert" className="text-xs text-red-600 font-medium text-right">{error}</p>}
        </form>
      </div>
    </div>
  );
}
