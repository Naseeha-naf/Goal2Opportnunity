# PostgreSQL local setup

The application uses PostgreSQL through Prisma. The local compose file uses PostgreSQL 17. Start it with:

```bash
docker compose -f docker-compose.postgres.yml up -d
npx prisma migrate dev --name init_postgres
```

The development credentials are intentionally local-only and are defined in `.env` and `docker-compose.postgres.yml`. Replace them, along with `AUTH_SECRET`, before any shared deployment.

The old SQLite file (`prisma/dev.db`) is not part of the PostgreSQL database and is not migrated automatically.
