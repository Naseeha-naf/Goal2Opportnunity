# Goal2Opportunity n8n ingestion

This workflow imports opportunities only from approved organizer feeds. It does not scrape search-result pages or invent event data.

## Before activation

1. Copy `.env.n8n.example` to `.env.n8n` and set both secrets.
2. Start n8n with `docker compose --env-file .env.n8n -f docker-compose.n8n.yml up -d`.
3. Open `http://localhost:5678`, create the owner account, and import `workflows/goal2opportunity-approved-source-import.json`.
4. In the workflow's `Approved sources` node, add only official JSON endpoints maintained by organizers or authorized aggregators.
5. Activate the workflow after the application ingestion endpoint and database migration are complete.

## Trust controls

- A source is allowlisted in the workflow, not taken from a user query.
- Each payload must include an official source URL and a source identifier.
- The application must verify the shared secret, normalize values, reject invalid URLs/dates, deduplicate by source URL, and record `retrievedAt`.
- Imports should begin as `PENDING_REVIEW`; only an admin can mark an opportunity `VERIFIED`.
- Expired registration deadlines must be excluded from search results, not deleted.

## Source policy

Prefer official organizer APIs, RSS/ICS feeds, university event APIs, and feeds explicitly permitted by the platform. Do not bypass authentication, robots restrictions, rate limits, or a site's terms of service.
