import { NextRequest, NextResponse } from 'next/server';
import { readSession } from '@/lib/auth/session';

export async function middleware(request: NextRequest) {
  const session = await readSession(request.cookies.get('g2o_session')?.value);
  if (session?.sub) return NextResponse.next();
  const signInUrl = new URL('/signin', request.url);
  signInUrl.searchParams.set('next', request.nextUrl.pathname);
  return NextResponse.redirect(signInUrl);
}

export const config = { matcher: ['/profile/:path*'] };
