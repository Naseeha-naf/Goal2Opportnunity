export type OpportunityType = 
  | 'Hackathon'
  | 'Workshop'
  | 'Competition'
  | 'Internship'
  | 'Open Source'
  | 'Research'
  | 'Startup'
  | 'Design'
  | 'Public Speaking'
  | 'Project Challenge';

export type EventMode = 'ONLINE' | 'OFFLINE' | 'HYBRID';
export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';

export interface OpportunityItem {
  id: string;
  title: string;
  slug: string;
  description: string;
  shortDescription: string;
  organizer: string;
  opportunityType: OpportunityType;
  domain: string;
  skills: string[];
  difficulty: SkillLevel;
  eligibilityText: string;
  eligibleYears: string[];
  eligibleDegrees: string[];
  location: string;
  city: string;
  state: string;
  country: string;
  mode: EventMode;
  fee: number;
  currency: string;
  startDate: string;
  endDate: string;
  registrationDeadline: string;
  teamAllowed: boolean;
  teamMin: number;
  teamMax: number;
  prize?: string | null;
  registrationUrl: string;
  sourceUrl?: string | null;
  isVerified: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface MatchScoreBreakdown {
  goalRelevance: number;      // 0-100 (35% weight)
  intentRelevance: number;    // 0-100 (20% weight)
  skillMatch: number;         // 0-100 (10% weight)
  budgetMatch: number;        // 0-100 (10% weight)
  eligibilityMatch: number;   // 0-100 (10% weight)
  availabilityMatch: number;  // 0-100 (5% weight)
  preferenceMatch: number;    // 0-100 (5% weight)
  freshnessScore: number;     // 0-100 (5% weight)
}

export interface RankedOpportunityResult {
  opportunity: OpportunityItem;
  totalScore: number; // 0-100 normalized score
  breakdown: MatchScoreBreakdown;
  reasons: string[];
  mismatches: string[];
  isHiddenMatch?: boolean;
  hiddenReason?: string;
}
