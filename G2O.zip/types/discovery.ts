import { OpportunityType, EventMode, SkillLevel } from './opportunity';

export interface EligibilityRequirement {
  year?: string | null;
  degree?: string | null;
  department?: string | null;
}

export interface SearchQueryModel {
  originalQuery: string;
  goal: string;
  intent: string;
  domains: string[];
  opportunityTypes: OpportunityType[];
  hardConstraints: string[];
  softPreferences: string[];
  flexibleConstraints: string[];
  negativeConstraints: string[];
  eligibility: EligibilityRequirement;
  location?: string | null;
  mode?: EventMode | 'ANY' | null;
  budgetMax?: number | null;
  dateRange?: 'THIS_WEEKEND' | 'NEXT_WEEKEND' | 'THIS_MONTH' | 'ANYTIME' | null;
  skillLevel?: SkillLevel | null;
  confidence?: Record<string, number>;
}

export interface ConstraintRelaxationOption {
  type: 'MODE' | 'LOCATION' | 'BUDGET' | 'DATE' | 'TYPE';
  label: string;
  description: string;
  recoveredCount: number;
  newMode?: EventMode;
  newBudgetMax?: number;
  newLocation?: string;
  newDateRange?: string;
}

export interface ConstraintResolutionResult {
  conflictReason: string;
  failingConstraints: string[];
  blockingConstraints: string[];
  recommendedRelaxation: ConstraintRelaxationOption;
  alternativeRelaxations: ConstraintRelaxationOption[];
  recoveredResultCount: number;
}
