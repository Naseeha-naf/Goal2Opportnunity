'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, ArrowRight, Lightbulb } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

const POPULAR_GOALS = [
  'AI Internship Preparation',
  'Build My Portfolio',
  'Hackathons',
  'Research Experience',
  'Public Speaking',
  'Startup Opportunities',
  'Open Source Experience',
];

export const GoalSearchBox: React.FC = () => {
  const router = useRouter();
  const { rawQuery, setRawQuery, executeSearch, isLoading } = useDiscovery();
  const [inputVal, setInputVal] = useState(rawQuery);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    setRawQuery(inputVal);
    await executeSearch(inputVal);
    router.push('/discover/understand');
  };

  const handleChipClick = (goalName: string) => {
    let queryStr = '';
    switch (goalName) {
      case 'AI Internship Preparation':
        queryStr = 'I want practical AI experience for internships. I’m a beginner, available on weekends, and my budget is under ₹500.';
        break;
      case 'Build My Portfolio':
        queryStr = 'I want to build my portfolio with hands-on project challenges and hackathons in web dev and AI.';
        break;
      case 'Hackathons':
        queryStr = 'Find weekend hackathons for undergraduate students with cash prizes and mentor guidance.';
        break;
      case 'Research Experience':
        queryStr = 'I want research poster challenges and paper publication opportunities in Machine Learning.';
        break;
      case 'Public Speaking':
        queryStr = 'Find public speaking workshops and tech pitch events under ₹300 in Coimbatore.';
        break;
      case 'Startup Opportunities':
        queryStr = 'I want to pitch a startup idea, join a team, and validate business models over the weekend.';
        break;
      case 'Open Source Experience':
        queryStr = 'Find free beginner friendly open source Python AI sprints online.';
        break;
      default:
        queryStr = `I want to achieve ${goalName} with beginner friendly student opportunities.`;
    }
    setInputVal(queryStr);
    setRawQuery(queryStr);
    executeSearch(queryStr);
    router.push('/discover/understand');
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Search Input Box */}
      <form onSubmit={handleSubmit} className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-brand-600 via-purple-600 to-indigo-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
        <div className="relative bg-white rounded-2xl shadow-xl border border-purple-100 p-3 sm:p-4 transition-all">
          <div className="flex items-start gap-3">
            <div className="mt-2 text-brand-600 shrink-0">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <textarea
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              rows={3}
              placeholder="I want practical AI experience for internships. I’m a beginner, available on weekends, and my budget is under ₹500."
              className="w-full text-slate-800 placeholder-slate-400 text-base sm:text-lg focus:outline-none resize-none bg-transparent font-medium"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between pt-4 border-t border-slate-100 gap-3">
            <p className="text-xs text-slate-500 flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              Describe your goal, interests, budget, availability, location, eligibility, or anything you want to avoid.
            </p>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-semibold px-6 py-3 rounded-xl transition-all shadow-md shadow-brand-600/30 hover:shadow-lg text-sm shrink-0"
            >
              {isLoading ? (
                <span>Understanding...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>✨ Discover Opportunities</span>
                  <ArrowRight className="w-4 h-4 ml-0.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Popular Goal Chips */}
      <div className="space-y-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Or select a popular student goal:
        </span>
        <div className="flex flex-wrap gap-2">
          {POPULAR_GOALS.map((goal) => (
            <button
              key={goal}
              type="button"
              onClick={() => handleChipClick(goal)}
              className="bg-white hover:bg-brand-50 hover:text-brand-700 text-slate-600 text-xs font-medium px-3.5 py-2 rounded-xl border border-slate-200 hover:border-brand-200 transition-all shadow-sm hover:shadow flex items-center gap-1.5"
            >
              <span>{goal}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
