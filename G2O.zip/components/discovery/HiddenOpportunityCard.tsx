'use client';

import React from 'react';
import Link from 'next/link';
import { Gem, ArrowRight, Sparkles } from 'lucide-react';
import { RankedOpportunityResult } from '@/types/opportunity';

interface HiddenOpportunityCardProps {
  hiddenMatch: RankedOpportunityResult;
}

export const HiddenOpportunityCard: React.FC<HiddenOpportunityCardProps> = ({ hiddenMatch }) => {
  const { opportunity } = hiddenMatch;

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-purple-900 via-indigo-900 to-slate-900 rounded-2xl text-white p-6 shadow-xl border border-purple-500/30 my-6">
      {/* Background Decorative Glow */}
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-brand-500/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-1.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
            <Gem className="w-4 h-4 text-amber-300 fill-amber-300" />
            <span>💎 HIDDEN OPPORTUNITY DISCOVERY</span>
          </div>

          {/* Title */}
          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {opportunity.title}
          </h3>

          {/* Explanation Text */}
          <p className="text-purple-100 text-sm leading-relaxed">
            You didn’t specifically search for a {opportunity.opportunityType.toLowerCase()}, but Goal2Opportunity AI discovered this event because it provides the hands-on project experience, teamwork, and portfolio proof you’re looking for.
          </p>

          {/* Footer Label */}
          <p className="text-xs text-purple-300/80 font-medium italic flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Discovered through goal relevance, not keyword similarity.
          </p>
        </div>

        {/* CTA Button */}
        <Link
          href={`/discover/hidden/${opportunity.id}`}
          className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-bold px-6 py-3 rounded-xl transition-all shadow-lg shadow-amber-500/20 shrink-0 text-sm"
        >
          <span>See Why We Found This</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
