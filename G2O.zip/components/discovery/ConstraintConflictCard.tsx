'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { AlertTriangle, Check, X, Sparkles, ArrowRight } from 'lucide-react';
import { ConstraintRelaxationOption, ConstraintResolutionResult } from '@/types/discovery';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

interface ConstraintConflictCardProps {
  conflict: ConstraintResolutionResult;
}

export const ConstraintConflictCard: React.FC<ConstraintConflictCardProps> = ({ conflict }) => {
  const router = useRouter();
  const { rawQuery, parsedQuery, executeSearch, setRawQuery } = useDiscovery();

  const handleApplyRelaxation = async (option: ConstraintRelaxationOption) => {
    // Clicking this control is the explicit user approval. The server receives
    // the approved structured change; it does not infer one from appended text.
    setRawQuery(rawQuery);
    await executeSearch(rawQuery, option);
    router.push('/discover/results');
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Conflict Header Box */}
      <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-amber-100 rounded-xl text-amber-700 shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-amber-950">No Exact Match Found</h2>
            <p className="text-sm text-amber-800 mt-1">
              We couldn’t find an opportunity that satisfies every requirement, but Goal2Opportunity AI found what’s preventing a match.
            </p>
          </div>
        </div>

        {/* Requirements Checklist */}
        <div className="pt-4 border-t border-amber-200/60">
          <h4 className="text-xs font-semibold text-amber-900 uppercase tracking-wider mb-2.5">
            Your Requirement Status
          </h4>
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="bg-emerald-100 text-emerald-800 font-medium px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> AI Related
            </span>
            <span className="bg-emerald-100 text-emerald-800 font-medium px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> Beginner Friendly
            </span>
            <span className="bg-emerald-100 text-emerald-800 font-medium px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> Free / Low Budget
            </span>
            <span className="bg-emerald-100 text-emerald-800 font-medium px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> Weekend Schedule
            </span>
            <span className="bg-rose-100 text-rose-800 font-semibold px-3 py-1.5 rounded-lg border border-rose-200 flex items-center gap-1">
              <X className="w-3.5 h-3.5 text-rose-600 stroke-[3]" /> Offline in Coimbatore
            </span>
          </div>
        </div>

        <div className="bg-white/80 rounded-xl p-3.5 border border-amber-200 text-xs font-medium text-amber-900">
          <strong>Conflict details:</strong> {conflict.conflictReason}
        </div>
      </div>

      {/* Recommended Relaxation Card */}
      <div className="bg-white rounded-2xl border-2 border-brand-500 shadow-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <div className="bg-brand-100 text-brand-700 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Goal2Opportunity AI Suggestion
          </div>
          <span className="text-xs text-slate-500 font-medium">Smallest Useful Change</span>
        </div>

        <div className="space-y-1">
          <h3 className="text-2xl font-extrabold text-slate-900">
            {conflict.recommendedRelaxation.label}
          </h3>
          <p className="text-slate-600 text-sm">
            {conflict.recommendedRelaxation.description}
          </p>
        </div>

        <div className="bg-brand-50 rounded-xl p-4 border border-brand-100 flex items-center justify-between">
          <div>
            <span className="text-xs text-brand-700 font-semibold uppercase tracking-wider">Expected Result</span>
            <p className="text-lg font-bold text-brand-950">
              ✨ {conflict.recoveredResultCount} matching opportunities become available
            </p>
          </div>

          <button
            onClick={() => handleApplyRelaxation(conflict.recommendedRelaxation)}
            className="bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all shadow-md shadow-brand-600/30 flex items-center gap-2"
          >
            <span>Show {conflict.recoveredResultCount} Opportunities</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Alternative Relaxations */}
      <div className="space-y-3">
        <h4 className="text-sm font-bold text-slate-700 uppercase tracking-wider">
          Alternative Relaxation Options:
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {conflict.alternativeRelaxations.map((alt, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl border border-slate-200 p-4 hover:border-brand-300 transition-all flex flex-col justify-between"
            >
              <div>
                <h5 className="font-bold text-slate-900 text-sm">{alt.label}</h5>
                <p className="text-xs text-slate-500 mt-1">{alt.description}</p>
              </div>

              <button
                onClick={() => handleApplyRelaxation(alt)}
                className="mt-3 text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
              >
                <span>Apply ({alt.recoveredCount} matches)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="text-center pt-2">
        <button
          onClick={() => router.push('/discover/results')}
          className="text-xs text-slate-500 hover:text-slate-700 font-medium underline"
        >
          Keep My Original Search & View Closest Partial Matches
        </button>
      </div>
    </div>
  );
};
