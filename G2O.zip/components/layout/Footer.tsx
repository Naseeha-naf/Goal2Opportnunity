'use client';

import React from 'react';
import Link from 'next/link';
import { Sparkles, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4 fill-white/20" />
              </div>
              <span className="font-bold text-lg text-white tracking-tight">
                Goal2Opportunity AI
              </span>
            </div>
            <p className="text-slate-300 text-sm max-w-sm">
              “Don’t search for opportunities. Tell us what you want to achieve.”
            </p>
            <p className="text-slate-500 text-xs">
              AI Smart Search & Discovery Assistant designed for student growth, internship prep, and portfolio building.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Quick Links</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  AI Discovery Home
                </Link>
              </li>
              <li>
                <Link href="/discover/results" className="hover:text-white transition-colors">
                  Recommended Opportunities
                </Link>
              </li>
              <li>
                <Link href="/profile/setup" className="hover:text-white transition-colors">
                  Student Profile Setup
                </Link>
              </li>
              <li>
                <Link href="/signin" className="hover:text-white transition-colors">
                  Student Sign In
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Opportunity Types</h4>
            <ul className="space-y-2.5 text-sm">
              <li>Generative AI Hackathons</li>
              <li>Open Source Sprints</li>
              <li>ML Project Challenges</li>
              <li>Research Poster Symposiums</li>
              <li>Cybersecurity CTF Competitions</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500">
          <p>© 2026 Goal2Opportunity AI. Built for hackathon demonstration.</p>
          <div className="flex items-center space-x-6 mt-4 sm:mt-0">
            <Link href="/signin" className="hover:text-slate-400">Terms of Service</Link>
            <Link href="/signin" className="hover:text-slate-400">Privacy Policy</Link>
            <span className="flex items-center gap-1 text-slate-400">
              Made with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for Students
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
