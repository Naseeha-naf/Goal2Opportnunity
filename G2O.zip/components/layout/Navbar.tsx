'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Sparkles, Compass, Bookmark, User, Search, Calendar } from 'lucide-react';
import { useDiscovery } from '@/lib/context/DiscoveryContext';

export const Navbar: React.FC = () => {
  const pathname = usePathname();
  const router = useRouter();
  const { user, savedOpportunityIds, signOut } = useDiscovery();

  const handleSignOut = async () => {
    await fetch('/api/auth/signout', { method: 'POST' });
    signOut();
    router.push('/');
    router.refresh();
  };

  const navLinks = [
    { href: '/', label: 'AI Discovery', icon: Sparkles, highlight: true },
    { href: '/discover/results', label: 'Explore', icon: Compass },
    { href: '/events/opp-001', label: 'Events', icon: Calendar },
    { href: '/profile', label: 'Saved', icon: Bookmark, badge: savedOpportunityIds.length },
    { href: '/profile', label: 'Profile', icon: User },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <Link href="/" className="flex items-center space-x-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-brand-600 flex items-center justify-center text-white shadow-md shadow-brand-500/20 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 fill-white/20" />
          </div>
          <div>
            <span className="font-bold text-lg text-slate-900 tracking-tight flex items-center gap-1.5">
              Goal2Opportunity
              <span className="bg-brand-100 text-brand-700 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-brand-200 uppercase tracking-wider">
                AI
              </span>
            </span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href;

            if (link.highlight) {
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-brand-600 text-white shadow-md shadow-brand-600/25'
                      : 'bg-brand-50 text-brand-700 hover:bg-brand-100 border border-brand-200'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>{link.label}</span>
                </Link>
              );
            }

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'text-brand-600 bg-brand-50/80 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
                <span>{link.label}</span>
                {link.badge !== undefined && link.badge > 0 && (
                  <span className="ml-1 bg-brand-100 text-brand-700 text-xs font-bold px-1.5 py-0.2 rounded-full">
                    {link.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Right Auth CTA */}
        <div className="flex items-center space-x-3">
          {user ? (
            <>
              <Link href="/profile" className="flex items-center gap-2 text-sm text-slate-700 hover:text-brand-600 px-3 py-1.5 rounded-lg hover:bg-slate-50 font-medium">
                <div className="w-7 h-7 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-xs">{user.name.charAt(0)}</div>
                <span className="hidden sm:inline">{user.name}</span>
              </Link>
              <button onClick={handleSignOut} className="text-xs font-semibold text-slate-500 hover:text-brand-600">Sign out</button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/signin"
                className="text-sm font-medium text-slate-700 hover:text-brand-600 px-3 py-2"
              >
                Sign In
              </Link>
              <Link
                href="/signup"
                className="text-sm font-medium bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl transition-colors shadow-sm"
              >
                Create Account
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
