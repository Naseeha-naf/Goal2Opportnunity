'use client';

import React from 'react';
import Link from 'next/link';
import { Calendar, MapPin, Check, Bookmark, Sparkles, Trophy, Users } from 'lucide-react';
import { RankedOpportunityResult } from '@/types/opportunity';
import { useDiscovery } from '@/lib/context/DiscoveryContext';
import { trackDiscoveryEvent } from '@/lib/analytics/client';

interface OpportunityCardProps {
  result: RankedOpportunityResult;
  onWhyMatchClick?: () => void;
}

export const OpportunityCard: React.FC<OpportunityCardProps> = ({ result, onWhyMatchClick }) => {
  const { toggleSaveOpportunity, savedOpportunityIds } = useDiscovery();
  const { opportunity, totalScore, reasons } = result;
  const isSaved = savedOpportunityIds.includes(opportunity.id);

  const formattedDate = new Date(opportunity.startDate).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });

  const formattedDeadline = new Date(opportunity.registrationDeadline).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-card hover:shadow-card-hover transition-all duration-200 overflow-hidden flex flex-col justify-between group">
      <div className="p-5 sm:p-6 space-y-4">
        {/* Top Header: Category Badge & Goal Match Score */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="bg-slate-100 text-slate-700 text-xs font-semibold px-2.5 py-1 rounded-md border border-slate-200">
              {opportunity.opportunityType}
            </span>
            <span className="bg-brand-50 text-brand-700 text-xs font-semibold px-2.5 py-1 rounded-md border border-brand-100">
              {opportunity.domain}
            </span>
            <span className="bg-emerald-50 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-md border border-emerald-100">
              {opportunity.difficulty}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Match Score Badge */}
            <div className="bg-gradient-to-r from-brand-600 to-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-sm flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
              <span>{totalScore}% Match</span>
            </div>

            {/* Save Button */}
            <button
              onClick={() => toggleSaveOpportunity(opportunity.id)}
              className={`p-1.5 rounded-lg border transition-colors ${
                isSaved
                  ? 'bg-brand-50 border-brand-300 text-brand-600'
                  : 'bg-white border-slate-200 text-slate-400 hover:text-slate-600'
              }`}
              title={isSaved ? 'Saved' : 'Save Opportunity'}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-brand-600' : ''}`} />
            </button>
          </div>
        </div>

        {/* Title & Organizer */}
        <div>
          <Link href={`/events/${opportunity.id}`} onClick={() => trackDiscoveryEvent('opportunity_opened', opportunity.id)} className="group-hover:text-brand-600 transition-colors">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
              {opportunity.title}
            </h3>
          </Link>
          <p className="text-xs text-slate-500 font-medium mt-1">
            Organized by <span className="text-slate-700 font-semibold">{opportunity.organizer}</span>
          </p>
        </div>

        {/* Key Event Metadata Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs text-slate-600 border-t border-slate-100">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Date: {formattedDate}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">{opportunity.location} ({opportunity.mode})</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Fee: {opportunity.fee === 0 ? 'Free' : `₹${opportunity.fee}`}</span>
          </div>

          {opportunity.prize && (
            <div className="flex items-center gap-1.5 text-brand-700 font-semibold truncate">
              <Trophy className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span className="truncate">{opportunity.prize}</span>
            </div>
          )}
        </div>

        {/* Why This Matches Grounded Rationale Box */}
        <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-3.5 space-y-1.5 text-xs text-emerald-950">
          <p className="font-bold text-emerald-900 flex items-center gap-1">
            <Check className="w-4 h-4 text-emerald-600 stroke-[3]" /> Why this matches your goal:
          </p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1 pl-1 text-emerald-800">
            {reasons.slice(0, 4).map((reason, idx) => (
              <li key={idx} className="flex items-center gap-1.5">
                <span className="text-emerald-500 font-bold">✓</span>
                <span>{reason}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Card Actions */}
      <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
        <Link
          href={`/discover/match/${opportunity.id}`}
          className="text-xs font-semibold text-brand-700 hover:text-brand-800 hover:underline flex items-center gap-1"
        >
          <Sparkles className="w-3.5 h-3.5 text-brand-600" />
          Why This Match?
        </Link>

        <Link
          href={`/events/${opportunity.id}`}
          onClick={() => trackDiscoveryEvent('opportunity_opened', opportunity.id)}
          className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-colors shadow-sm"
        >
          View Opportunity
        </Link>
      </div>
    </div>
  );
};
